function x = RootsLegendre(n)
% computes roots of the Legendre polynomial P_n(x)
c = poly([ones(1,n),-ones(1,n)]);
for m = 1 : n
c = polyder(c);
end
x = sort(roots(c));