function Dnum = CentRichExtrap(f,x0,h,maxRich)
% evaluates Richardson extrapolations for central differences
% f - string for the name of function f(x)
% x0 - given point where f'(x0) is approximated
% h - given step size of a uniform grid
% maxRich - number of Richardson extrapolations
% Dnum - row-vector of Richardson extrapolations

D = ones(maxRich,maxRich);
x = [x0-2.^(maxRich-1:-1:0)*h,x0,x0+2.^(0:maxRich-1)*h];
y = eval(f);
D(:,1) = (y(maxRich+2:2*maxRich+1)'-y(maxRich:-1:1)')./ ...
            (x(maxRich+2:2*maxRich+1)'-x(maxRich:-1:1)');
for k = 2 : maxRich
    for kk = 1 : (maxRich-k+1)
        D(kk,k) = D(kk,k-1)+(D(kk,k-1)-D(kk+1,k-1))/(4^(k-1)-1);
    end
end
Dnum = D(1,:);