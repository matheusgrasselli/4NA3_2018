n1 = 10; n2 = 1000; k = 1;
for n = n1 : 1 : n2
	h = 1/n; x = 1+[0,h,2*h]; y = x.^5; 
    IntExact = ((1+2*h)^6-1)/6; 
    IntSimp = h*(y(1)+4*y(2) + y(3))/3; % Simpson rule
    ErrSimp(k) = abs(IntSimp-IntExact);  
    x = 1+[0,0.5*h,2*h]; y = x.^5;      % three-point rule
    IntGen = (x(3)-x(1))*((-2*x(1)+3*x(2)-x(3))/(x(2)-x(1))*y(1) ...
        + (-4*x(1)+3*x(2)+x(3))/(x(2)-x(1))*y(2) ...
        + (x(1)-3*x(2)+2*x(3))/(x(3)-x(2))*(y(3)-y(2)))/6;  
    ErrGen(k) = abs(IntGen-IntExact); 
    hst(k) = h;  k = k+1;
end
aSimp = polyfit(log(hst),log(ErrSimp),1); powerSimp = aSimp(1)
aGen = polyfit(log(hst),log(ErrGen),1); powerGen = aGen(1)



