% linear_splines
x = linspace(-3,3,31);
n = length(x)-1;
y = 1./(1+25*x.^2)+1./(1+5*(x-1).^2);
y0 = y(1:n);
m = diff(y)./diff(x);
xInt = linspace(-3,3,1001);
for j = 1 : length(xInt)
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end
xx = xInt-x(iInt);         % linear functions for evaluations of splines
yInt = y0(iInt)+m(iInt).*xx;
yEx = 1./(1+25*xInt.^2)+1./(1+5*(xInt-1).^2);
plot(x,y,'b.',xInt,yInt,'g',xInt,yEx,'r:');