function w = MultiCentralDiff(m)
% computes coefficients of the (2m+1)-point central difference

x = linspace(-1,1,2*m+1);
h = 1/m;
A = fliplr(vander(x))';
AA = [A(2:2*m+1,1:m),A(2:2*m+1,m+2:2*m+1)];
b = eye(2*m);
bb = b(:,1);
ww = h*(AA\bb)';
w = [ww(1:m),0,ww(m+1:2*m)];
