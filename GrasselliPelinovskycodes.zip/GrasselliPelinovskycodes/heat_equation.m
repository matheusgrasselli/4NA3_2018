% heat_equation
h = 0.1;
x = 0:h:1;
n = length(x)-1;
tau = 0.005;
 t = 0:tau:0.6;
m = length(t)-1;
m2 = 1+m/2;
r = tau/h^2;
U1 = zeros(length(x),length(t));
U1(:,1) = sin(pi*x');
U2 = U1;
U3 = U1;
f = sin(3*pi*x)';
A1 = (1-2*r)*diag(ones(1,n-1))+r*(diag(ones(1,n-2),1)+diag(ones(1,n-2),-1));
A2 = (1+2*r)*diag(ones(1,n-1))-r*(diag(ones(1,n-2),1)+diag(ones(1,n-2),-1));
A3 = 2*(1-r)*diag(ones(1,n-1))+r*(diag(ones(1,n-2),1)+diag(ones(1,n-2),-1));
A4 = 2*(1+r)*diag(ones(1,n-1))-r*(diag(ones(1,n-2),1)+diag(ones(1,n-2),-1));
for k = 1 : m
    U1(2:n,k+1) = A1*U1(2:n,k)+tau*f(2:n);
    U2(2:n,k+1) = inv(A2)*(U2(2:n,k)+tau*f(2:n));
        U3(2:n,k+1) = inv(A4)*(A3*U3(2:n,k)+2*tau*f(2:n));
end
T = 0.3;
xInt = 0:0.01:1;
Uex = exp(-pi^2*T)*sin(pi*xInt)+(1-exp(-9*pi^2*T))*sin(3*pi*xInt)/(9*pi^2);
figure(1); hold on;
plot(x',U1(:,m2),'r',x',U2(:,m2),'b',x',U3(:,m2),'g',xInt,Uex,':k');
plot(x',U1(:,m2),'*r',x',U2(:,m2),'*b',x',U3(:,m2),'*g');
[T,X] = meshgrid(t,x);
Uex = exp(-pi^2*T).*sin(pi*X)+(1-exp(-9*pi^2*T)).*sin(3*pi*X)/(9*pi^2);
E1 = max(abs(U1-Uex));
E2 = max(abs(U2-Uex));
E3 = max(abs(U3-Uex));
figure(2); plot(t,E1,'r',t,E2,'b',t,E3,'g');