for k = 1 : 5
    c = poly([ones(1,k),-ones(1,k)]);
    for m = 1 : k
        c = polyder(c);
    end
    x = roots(c)';  % zeros of Legendre polynomials
    A = fliplr(vander(x))';
    b = k./(1:k)'; b(2:2:k) = 0;
    w = (A\b)';     % weights of the Gaussian quadrature
    C = 2^(2*k+1)*factorial(k)^4/(factorial(2*k+1)*factorial(2*k));
    E = (2/(2*k+1)-2*w*(x'.^(2*k))/k)/C
end



