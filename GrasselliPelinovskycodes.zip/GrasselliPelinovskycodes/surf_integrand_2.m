function g=surf_integrand_2(u,v)

% tangent vectors:

tu=[2*cos(u).*cos(v);2*cos(u).*sin(v);-2*sin(u)];

tv=[-2*sin(u).*sin(v);2*sin(u).*cos(v);zeros(1,length(u))];

% normal vector with the correct orientation:

N=cross(tv,tu);

% curl of the vector field evaluated on the surface:

curlf=[exp((2*sin(u).*cos(v)).^2)-8*sin(u).*sin(v).*cos(u);

    -8*sin(u).^2*cos(v).*sin(v).*exp((2*sin(u).*cos(v)).^2);

    2*sin(u).*cos(v).*exp(8*sin(u).^2*cos(v).*sin(v))];

% normal component

for i=1:length(u)

    g(i)=curlf(:,i)'*N(:,i);

end                       