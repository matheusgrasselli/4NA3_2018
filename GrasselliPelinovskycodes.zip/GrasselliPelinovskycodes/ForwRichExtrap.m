function Dnum = ForwRichExtrap(f,x0,h,maxRich)
% evaluates Richardson extrapolations for forward differences
% f - string for the name of function f(x)
% x0 - given point where f'(x0) is approximated
% h - given step size of a uniform grid
% maxRich - number of Richardson extrapolations
% Dnum - row-vector of Richardson extrapolations

D = ones(maxRich,maxRich);
x = [x0,x0+2.^(0:maxRich-1)*h];
y = eval(f);
D(:,1) = (y(2:maxRich+1)'-y(1))./(x(2:maxRich+1)'-x(1));
for k = 2 : maxRich
    for kk = 1 : (maxRich-k+1)
        D(kk,k) = D(kk,k-1)+(D(kk,k-1)-D(kk+1,k-1))/(2^(k-1)-1);
    end
end
Dnum = D(1,:);