% polynomial_wiggle
figure(1); hold on; 
for n = 4 : 4 : 12
    x = linspace(-1,1,n+1); 
    y = 1./(1+25*x.^2); 
    c = polyfit(x,y,n); 
    xInt = linspace(-1,1,1000); 
    yInt = polyval(c,xInt); 
    plot(xInt,yInt,x,y,'*'); 
end
yExact = 1./(1+25*xInt.^2);
plot(xInt,yExact,':r'); hold off;

figure(2); hold on; 
for n = 4 : 4 : 20
    x = linspace(-0.1,0.1,n+1); 
    y = 1./(1+25*x.^2); 
    c = polyfit(x,y,n); 
    xInt = linspace(-0.1,0.1,1000); 
    yInt = polyval(c,xInt); 
    plot(xInt,yInt,x,y,'*'); 
end
yExact = 1./(1+25*xInt.^2);
plot(xInt,yExact,':r'); hold off;