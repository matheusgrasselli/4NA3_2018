t(1) = 0; y(1) = 1; yH(1) = 1; T = 18; h = 0.1; n = T/h;
t(2) = t(1) + h;    % first step (necessary for Adams method)
y(2) = exp(-t(2)^2); yH(2) = y(2);
for k = 2 : n
	t(k+1) = t(k) + h;
	y(k+1) = y(k) - h*(3*t(k)*y(k)-t(k-1)*y(k-1));
    p = yH(k) - 2*h*t(k)*yH(k);
    yH(k+1) = yH(k) - h*(t(k)*yH(k)+t(k+1)*p);
end   
yExact = exp(-t.^2); 
plot(t,yExact,':r',t,y,'.b',t,yH,'.g');
axis([0,T,-0.5,1]);


