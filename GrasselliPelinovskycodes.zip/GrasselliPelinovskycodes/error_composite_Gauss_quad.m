% error_composite_Gauss_quad
IntExact = 1;
k = 1;
n1 = 1;
n2 = 200;
for n = n1 : 1 : n2
x = linspace(0,pi/2,n+1);
    h = x(2)-x(1);
    xM = x + 0.5*h;
    yM = cos(xM);
    x1 = xM-h/(2*sqrt(3));
    x2 = xM+h/(2*sqrt(3));
    y1 = cos(x1);
y2 = cos(x2);
xx1 = xM-h*sqrt(3/5)/2;
xx2 = xM+h*sqrt(3/5)/2;
yy1 = cos(xx1);
yy2 = cos(xx2);
z1 = sqrt((15+sqrt(120))/35);
z2 = sqrt((15-sqrt(120))/35);
xz1 = xM-h*z1/2;
xz2 = xM+h*z1/2;
xz3 = xM-h*z2/2;
xz4 = xM+h*z2/2;
yz1 = cos(xz1);
yz2 = cos(xz2);
yz3 = cos(xz3);
yz4 = cos(xz4);
   % two-point quadrature
  % three-point quadrature
% four-point quadrature
  IntGauss1 = h*sum(yM(1:n));
    IntGauss2 = h*(sum(y1(1:n))+sum(y2(1:n)))/2;
    IntGauss3 = h*(5*sum(yy1(1:n))/6+5*sum(yy2(1:n))/6+4*sum(yM(1:n))/3)/3;
    IntGauss4 = h*(0.695709690274908*(sum(yz1(1:n))+sum(yz2(1:n))) ...
                    +1.304290309725092*(sum(yz3(1:n))+sum(yz4(1:n))))/4;
    ErrGauss1(k) = abs(IntGauss1-IntExact);
    ErrGauss2(k) = abs(IntGauss2-IntExact);
    ErrGauss3(k) = abs(IntGauss3-IntExact);
    ErrGauss4(k) = abs(IntGauss4-IntExact);
    hst(k) = h;
k = k+1; end
mSpan = 1:10;
aGauss1 = polyfit(log(hst(mSpan)),log(ErrGauss1(mSpan)),1);
powerGauss1 = aGauss1(1)
aGauss2 = polyfit(log(hst(mSpan)),log(ErrGauss2(mSpan)),1);
powerGauss2 = aGauss2(1)
aGauss3 = polyfit(log(hst(mSpan)),log(ErrGauss3(mSpan)),1);
powerGauss3 = aGauss3(1)
aGauss4 = polyfit(log(hst(mSpan)),log(ErrGauss4(mSpan)),1);
powerGauss4 = aGauss4(1)
loglog(hst,ErrGauss1,'.r',hst,ErrGauss2,'.g', ...
            hst,ErrGauss3,'.b',hst,ErrGauss4,'.m');