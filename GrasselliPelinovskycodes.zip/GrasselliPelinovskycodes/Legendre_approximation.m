% Legendre_approximation
x = linspace(-1,1,101);
n = length(x)-1;
y = cos(pi*x);
c(1) = 0;
c(2) = 0;
c(3) = -6/pi^2;
c(4) = 0;
c(5) = 2*(105-10*pi^2)/pi^4;
c(6) = 0;
c(7) = -42*(495-60*pi^2+pi^4)/pi^6;
p(1,:) = ones(size(x));
p(2,:) = x;
p(3,:) = (3*x.^2-1)/2;
p(4,:) = (5*x.^3-3*x)/2;
p(5,:) = (35*x.^4-30*x.^2+3)/8;
p(6,:) = (63*x.^5-70*x.^3+15*x)/8;
p(7,:) = (231*x.^6-315*x.^4+105*x.^2-5)/16;
for m = 0 : 2 : 6
    yy = zeros(size(x));
    Error = 1;
    for k = 1 : m+1
        yy = yy + (2*k-1)*c(k)*p(k,:)/2;
        Error = Error - (2*k-1)*c(k)^2/2;
    end
    fprintf('m = %d, E = %2.15f\n',m,Error);
    if m == 2
        plot(x,y,'b.',x,yy,'g'); hold on;
    elseif m == 6
        plot(x,y,'b.',x,yy,'r'); hold off;
    end
end
