h = 0.05; y0 = 1; T = 3; n = T/h; 
t(1) = 0; yRK3(1) = y0; yRK4(1) = y0; 
        % third-order and fourth-order Runge-Kutta methods
for k = 1 : n
	t(k+1) = t(k) + h;
    fRK3 = -2*t(k)*yRK3(k); fRK4 = -2*t(k)*yRK4(k);
    pRK3 = yRK3(k) + h*fRK3/2; pRK4 = yRK4(k) + h*fRK4/2; 
    gRK3 = -2*(t(k)+h/2)*pRK3; gRK4 = -2*(t(k)+h/2)*pRK4;
    qRK3 = yRK3(k) - h*fRK3 + 2*h*gRK3; qRK4 = yRK4(k) + h*gRK4/2; 
    hRK4 = -2*(t(k)+h/2)*qRK4; rRK4 = yRK4(k) + h*hRK4;
    ffRK3 = -2*t(k+1)*qRK3; ffRK4 = -2*t(k+1)*rRK4;
    yRK3(k+1) = yRK3(k) + h*(fRK3+4*gRK3+ffRK3)/6;
	yRK4(k+1) = yRK4(k) + h*(fRK4+2*gRK4+2*hRK4+ffRK4)/6;
end
yExact = exp(-t.^2);   % errors of the Runge-Kutta methods
eRK3 = abs(yRK3-yExact); normRK3 = max(eRK3)
eRK4 = abs(yRK4-yExact); normRK4 = max(eRK4)
figure(1); plot(t,eRK3,'.b');
figure(2); plot(t,eRK4,'.g');
