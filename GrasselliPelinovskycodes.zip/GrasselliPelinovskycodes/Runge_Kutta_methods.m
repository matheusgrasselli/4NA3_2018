% Runge_Kutta_methods
h = 0.05;
y0 = 1;
T = 3;
n = T/h;
t(1) = 0;
yRK3(1) = y0;
yRK4(1) = y0;
for k = 1 : n
    t(k+1) = t(k)+h;
    fRK3 = -2*t(k)*yRK3(k);
    fRK4 = -2*t(k)*yRK4(k);
    pRK3 = yRK3(k)+h*fRK3/2;
    pRK4 = yRK4(k)+h*fRK4/2;
    gRK3 = -2*(t(k)+h/2)*pRK3;
    gRK4 = -2*(t(k)+h/2)*pRK4;
    qRK3 = yRK3(k)-h*fRK3+2*h*gRK3;
    qRK4 = yRK4(k)+h*gRK4/2;
    hRK4 = -2*(t(k)+h/2)*qRK4;
    rRK4 = yRK4(k)+h*hRK4;
    ffRK3 = -2*t(k+1)*qRK3;
    ffRK4 = -2*t(k+1)*rRK4;
    yRK3(k+1) = yRK3(k)+h*(fRK3+4*gRK3+ffRK3)/6;
    yRK4(k+1) = yRK4(k)+h*(fRK4+2*gRK4+2*hRK4+ffRK4)/6;
end
yExact = exp(-t.^2);
normRK3 = max(abs(yRK3-yExact))
normRK4 = max(abs(yRK4-yExact))
figure(1); plot(t,abs(yRK3-yExact),'.b');
figure(2); plot(t,abs(yRK4-yExact),'.g');
