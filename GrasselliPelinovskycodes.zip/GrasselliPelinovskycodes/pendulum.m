% pendulum
h = 0.1;
t = 0 : h : 30;
for j = 1 : 2
xE(j,:) = zeros(size(t)); 
yE(j,:) = zeros(size(t)); 
xH(j,:) = zeros(size(t)); 
yH(j,:) = zeros(size(t)); 
if(j==1)     % two initial conditions
        xE(j,1) = pi/4;
        yE(j,1) = 0;
        xH(j,1) = pi/4;
        yH(j,1) = 0;
    else
        xE(j,1) = -pi;
        yE(j,1) = 0.05;
        xH(j,1) = -pi;
        yH(j,1) = 0.05;
    end
    for k = 1 : (length(t)-1)
        xE(j,k+1) = xE(j,k)+h*yE(j,k);
        yE(j,k+1) = yE(j,k)-h*sin(xE(j,k));
        pk = xH(j,k)+h*yH(j,k);
        qk = yH(j,k)-h*sin(xH(j,k));
        xH(j,k+1) = xH(j,k)+0.5*h*(yH(j,k) + qk);
        yH(j,k+1) = yH(j,k)-0.5*h*(sin(xH(j,k)) + sin(pk));
    end
    figure(j); plot(t,xE(j,:),'b',t,xH(j,:),'r');
end