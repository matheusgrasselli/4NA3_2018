% nonlinear_wave_equation
h = 0.1; x = -10 : h : 10; 
nX = length(x)-1; x1 = x(1:nX);
tau = 0.01; r = tau/h; 
t = 0 : tau : 10; nT = length(t); 
U = zeros(nX,nT); U(:,1) = exp(-x1'.*x1');  % initial conditions
d1 = diag(ones(1,nX)); 
d2 = diag(ones(1,nX-1),1)+diag(ones(1,nX-1),-1);
A = 2*(1-r^2)*d1+r^2*d2; A(1,nX) = r^2; A(nX,1) = r^2;
U(:,2) = 0.5*A*U(:,1);                      % first step
for k = 3 : nT                              % explicit method
        U(:,k) = A*U(:,k-1)-U(:,k-2)+tau^2*U(:,k-1).*(U(:,k-1).^2-1); 
end
U = [ U; U(1,:) ];
U = U(:,1:10:nT); t = t(1:10:nT);
[X,T] = meshgrid(x,t);
figure(1); surf(X,T,U');
xlabel('x'); ylabel('t'); zlabel('u');



