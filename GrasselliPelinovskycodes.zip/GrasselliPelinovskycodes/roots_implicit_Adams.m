% roots_implicit_Adams
hSpan = linspace(0,10,101);
for j = 1 : length(hSpan)
h = hSpan(j);
    q1(:,j) = roots([1,-(1-8*h/12)/(1+5*h/12),-(h/12)/(1+5*h/12)])';
end
figure(1); plot(hSpan,q1,'.b');
for j = 1 : length(hSpan)
    h = hSpan(j);
    q2(:,j) = roots([1,-(1-19*h/24)/(1+9*h/24), ...
                -(5*h/24)/(1+9*h/24),(h/24)/(1+9*h/24)])';
end
figure(2); plot(hSpan,q2,'.b');