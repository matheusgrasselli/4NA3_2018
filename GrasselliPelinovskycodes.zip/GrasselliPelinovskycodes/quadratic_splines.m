% quadratic_splines
x = linspace(-3,3,31);
n = length(x)-1;
y = 1./(1+25*x.^2)+1./(1+5*(x-1).^2);
xInt = linspace(-3,3,1001);
for j = 1 : length(xInt)
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end
xx = xInt-x(iInt);
y0 = y(1:n);
Diff1 = (y(2:n+1)-y(1:n))./(x(2:n+1)-x(1:n));
m(1) = Diff1(1);
m(2) = m(1);
for k = 2 : n
    m(k+1) = -m(k)+2*Diff1(k);
end
b = (m(2:n+1)-m(1:n))./(x(2:n+1)-x(1:n));
m = m(1:n);
yInt = y0(iInt)+m(iInt).*xx+0.5*b(iInt).*xx.^2;
yEx = 1./(1+25*xInt.^2)+1./(1+5*(xInt-1).^2);
plot(x,y,'b.',xInt,yInt,'g',xInt,yEx,'r:');