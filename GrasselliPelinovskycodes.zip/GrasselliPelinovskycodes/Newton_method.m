% Newton_method
% function f(x) = 2*log(x)+sqrt(x)-2
xZeroMATLAB = fzero('2*log(x)+sqrt(x)-2',1.5); epsilon = 1;
tol=0.0000001; total = 100; x(1) = 1; k = 1;
Error(1)=abs(x(1)-xZeroMATLAB);
% iterations of the Newton method
while ((epsilon > tol) & (k < total))
    f = 2*log(x(k))+sqrt(x(k))-2;
    fDer = 2/x(k)+1/(2*sqrt(x(k)));
    x(k+1) = x(k)-f/fDer;
    epsilon = abs(x(k+1)-x(k));
    Error1(k+1) = abs(x(k+1) - xZeroMATLAB);
    k = k+1;
end
fprintf('Root x = %12.10f found after %2.0f iterations\n',x(k),k-1);
% function f(x) = (x-1)^6
epsilon = 1; tol = 0.0000001; total = 100; x(1) = 0; j = 1;
Error2(1)=abs(x(1)-1);
% iterations of the Newton method
while ((epsilon > tol) & (k < total))
    f = (x(j)-1)^6;
    fDer = 6*(x(j)-1)^5;
    x(j+1) = x(j)-f/fDer;
    epsilon = abs(x(j+1)-x(j));
    Error2(j+1) = abs(x(j+1) - 1);
    j = j+1;
   end
fprintf('Root x = %12.10f found after %2.0f iterations \n',x(j),j-1);