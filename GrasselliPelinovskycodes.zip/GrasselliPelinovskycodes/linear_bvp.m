h = 0.01; z = -1 : h : 1;
n = length(z)-1; zz = z(2:n); gamma = 1;
% building and solving the linear system
 A1 = -2*diag(ones(n-1,1))+diag(ones(n-2,1),1)+diag(ones(n-2,1),-1);
 A2 = -h^2*diag((1 - gamma*(1-zz.^2))./(1-zz.^2).^2);
 A3 = -h*diag(zz(1:n-2)./(1-zz(1:n-2).^2),1);
 A4 = +h*diag(zz(2:n-1)./(1-zz(2:n-1).^2),-1);
 A = A1 + A2 + A3 + A4;
b = -h^2*((1-zz.^2).^(3/2))';
yIn = A\b; xIn = atanh(zz)';
zInt = linspace(-1,1,11001); 
xInt = atanh(zInt(2:length(zInt)-1));
yInt = spline(zz,yIn,zInt);
yInt = yInt(2:length(yInt)-1);
figure(1); plot(xInt,yInt,'r',xIn,yIn,'.g');

gammaSpan = 1 : 0.01 : 3;
for k = 1 : length(gammaSpan)
    gamma = gammaSpan(k);
    A1 = -2*diag(ones(n-1,1))+diag(ones(n-2,1),1)+diag(ones(n-2,1),-1);
    A2 = -h^2*diag((1 - gamma*(1-zz.^2))./(1-zz.^2).^2);
    A3 = -h*diag(zz(1:n-2)./(1-zz(1:n-2).^2),1);
    A4 = +h*diag(zz(2:n-1)./(1-zz(2:n-1).^2),-1);
    A = A1 + A2 + A3 + A4;
    b = -h^2*((1-zz.^2).^(3/2))';
    yIn = A\b; 
    maxSolution(k) = max(abs(yIn));
end
figure(2); plot(gammaSpan,maxSolution,'.',gammaSpan,maxSolution);

