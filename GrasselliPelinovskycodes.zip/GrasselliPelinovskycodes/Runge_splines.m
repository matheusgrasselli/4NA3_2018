% Runge_splines
for n = 4 : 4 : 12
    x = linspace(-1,1,n+1);
    y = 1./(1+25*x.^2);
    h = x(2:n+1)-x(1:n);
    A = 2*diag(h(1:n-1))+2*diag(h(2:n))+diag(h(2:n-1),1)+diag(h(2:n-1),-1);
    Diff2 = (y(3:n+1)-y(2:n))./h(2:n)-(y(2:n)-y(1:n-1))./h(1:n-1);
    b = A\(6*Diff2');
    b = [0;b;0]';
    y0 = y(1:n);
    m = (y(2:n+1)-y(1:n))./h(1:n)-h(1:n).*(b(2:n+1)+2*b(1:n))/6;
    gamma = (b(2:n+1)-b(1:n))./h(1:n);
    xInt = linspace(-1,1,1001);
    for j = 1 : length(xInt)
        if xInt(j) ~= x(n+1)
            iInt(j) = sum(x <= xInt(j));
        else
            iInt(j) = n;
        end
    end
    xx = xInt-x(iInt);
    yInt = y0(iInt)+m(iInt).*xx+0.5*b(iInt).*xx.^2+gamma(iInt).*xx.^3/6;
    plot(xInt,yInt,x,y,'*');
end
yExact = 1./(1+25*xInt.^2);
plot(xInt,yExact,':r');
