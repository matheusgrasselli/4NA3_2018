% roots_explicit_Adams
hSpan = linspace(0,1,101);
for j = 1 : length(hSpan)
h = hSpan(j);
    q2(:,j) = roots([1,-1+3*h/2,-h/2])';
end
figure(1); plot(hSpan,q2,'.b');