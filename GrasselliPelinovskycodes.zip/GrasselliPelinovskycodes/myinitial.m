function yinit = myinitial(x)
% function myinitial defines the starting approximation
    yinit = [1./(1+x.^2); -2*x./(1+x.^2).^2];

