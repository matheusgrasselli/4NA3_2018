% composite_rules
IntExact = 1;
k = 1;
n1 = 12;
n2 = 12000;
for n = n1 : 12 : n2
    x = linspace(0,pi/2,n+1);
    h = x(2)-x(1);
    y = cos(x);
    IntTrap = h*(y(1)+2*sum(y(2:n))+y(n+1))/2;
    IntSimp = h*(y(1)+4*sum(y(2:2:n))+2*sum(y(3:2:n-1))+y(n+1))/3;
    IntSimp38 = 3*h*(y(1)+3*sum(y(2:3:n-1))+3*sum(y(3:3:n)) ...
                    +2*sum(y(4:3:n-2))+y(n+1))/8;
    IntBoole = 2*h*(7*y(1)+32*sum(y(2:4:n-2))+12*sum(y(3:4:n-1)) ...
                    +32*sum(y(4:4:n))+14*sum(y(5:4:n-3))+7*y(n+1))/45;
    ErrTrap(k) = abs(IntTrap-IntExact);
    ErrSimp(k) = abs(IntSimp-IntExact);
    ErrSimp38(k) = abs(IntSimp38-IntExact);
    ErrBoole(k) = abs(IntBoole-IntExact);
    hst(k) = h;
k = k+1; end
mSpan = 1:20;
aTrap = polyfit(log(hst(mSpan)),log(ErrTrap(mSpan)),1);
powerTrap = aTrap(1)
aSimp = polyfit(log(hst(mSpan)),log(ErrSimp(mSpan)),1);
powerSimp = aSimp(1)
aSimp38 = polyfit(log(hst(mSpan)),log(ErrSimp38(mSpan)),1);
powerSimp38 = aSimp38(1)
aBoole = polyfit(log(hst(mSpan)),log(ErrBoole(mSpan)),1);
powerBoole = aBoole(1)
loglog(hst,ErrTrap,'.g',hst,ErrSimp,'.r',hst,ErrSimp38,'.b',hst,ErrBoole,'.c');