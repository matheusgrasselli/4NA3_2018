% error_heat_equation
T = 0.1;
for h = 0.05 : 0.05 : 0.1
    x = 0 : h : 1; n = length(x) - 1;
    tau1 = 0.1*h^2; t1 = 0 : tau1 : T; 
    m1 = length(t1)-1; r1 = tau1/h^2;
    U1 = zeros(length(x),length(t1));
    tau2 = 0.1*h; t2 = 0 : tau2 : T; 
    m2 = length(t2)-1; r2 = tau2/h^2;
    U2 = zeros(length(x),length(t2));
    U3 = zeros(length(x),length(t2));
    U1(:,1) = sin(2*pi*x'); U2(:,1) = sin(2*pi*x'); 
    U3(:,1) = sin(2*pi*x'); d1 = diag(ones(1,n-1));
    d2 = diag(ones(1,n-2),1)+diag(ones(1,n-2),-1);
    A1 = (1 - 2*r1)*d1 + r1*d2; A2 = (1 + 2*r2)*d1 - r2*d2;
    A3 = (1 - r2)*d1 + 0.5*r2*d2; A4 = (1 + r2)*d1 - 0.5*r2*d2;
    for k = 1 : m1
        U1(2:n,k+1) = A1*U1(2:n,k);
    end
    for k = 1 : m2
        U2(2:n,k+1) = inv(A2)*U2(2:n,k);
        U3(2:n,k+1) = inv(A4)*A3*U3(2:n,k);
    end
    Uex = exp(-4*pi^2*T)*sin(2*pi*x);
    if (h == 0.05)
        E1a = max(abs(U1(:,m1+1)-Uex'));
        E2a = max(abs(U2(:,m2+1)-Uex'));
        E3a = max(abs(U3(:,m2+1)-Uex'));
        fprintf('E1a = %f, E2a = %f, E3a = %f\n',E1a,E2a,E3a); 
    elseif (h == 0.1)
        E1b = max(abs(U1(:,m1+1)-Uex'));
        E2b = max(abs(U2(:,m2+1)-Uex'));
        E3b = max(abs(U3(:,m2+1)-Uex'));
        fprintf('E1b = %f, E2b = %f, E3b = %f\n',E1b,E2b,E3b); 
        r1 = E1b/E1a; r2 = E2b/E2a; r3 = E3b/E3a;
        fprintf('r1 = %f, r2 = %f, r3 = %f\n',r1,r2,r3); 
    end
end
