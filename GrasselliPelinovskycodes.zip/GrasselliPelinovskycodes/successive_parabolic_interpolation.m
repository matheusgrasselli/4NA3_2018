% successive_parabolic_interpolation
tol = 0.000001; k = 0;
options = optimset('TolX',tol); % sets the tolerance for fminbnd
[xmin,fmin] = fminbnd('x*sin(1/x)',0.1,0.5,options);
a = 0.15; b = 0.5;     % initial interval
x1 = a; x2 = (a+b)/2; x3 = b;  % initial three points
while x3-x1 > tol   % the successive parabolic interpolation
    y1 = x1*sin(1/x1); y2 = x2*sin(1/x2); y3 = x3*sin(1/x3);
    x = ((y2-y1)*(x3^2-x2^2)-(y3-y2)*(x2^2-x1^2))/...
        (2*((y3-y2)*(x1-x2)+(y2-y1)*(x3-x2)));
    if (x2-x)>0       % minimum must be to the left
        x3=x2;
    else              % minimum must be to the right
        x1=x2;
    end
    x2=x;
    Error=abs(x-xmin);k=k+1;
end
fprintf('x = %12.10f, Error= %12.10f, k= %2.0f \n',x,Error,k);