function m=msphere(u,v)
% computes tangent vectors, normal vector and elementary masses
ell = length(u);
tu = [2*cos(u)*cos(v);2*cos(u)*sin(v);-2*sin(u)];
tv = [-2*sin(u)*sin(v);2*sin(u)*cos(v);zeros(1,ell)];
n = cross(tu,tv); % normal vector
for i=1:ell
    z(i)=norm(n(:,i));
end
m = 4*(cos(u).^2).*z; % elementary masses