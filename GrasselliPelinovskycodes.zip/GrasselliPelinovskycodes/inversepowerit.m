function Y = inversepowerit(A,x0,maxit,tol)
% inverse power iteration to find the
% minimal eigenpair of A
% x0 initial column vector
% tol is the tolerance bound

[L,U] = lufactor(A); x = x0; error = 1; i = 0;
 while (i <= maxit) & (error > tol)
    w = backsub(U,forwsub(L,x));
    x = w./norm(w,inf);
    lambda = (x'*A*x)/(x'*x);
    error = norm(A*x-lambda*x,inf);
    i = i + 1;
    Y(i,:) = [x;lambda;error].';
end
