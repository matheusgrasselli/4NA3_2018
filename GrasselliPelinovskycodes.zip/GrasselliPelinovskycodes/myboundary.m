function res = myboundary(ya,yb)
% function myboundary defines the separated boundary conditions
    res = [ ya(1); yb(1) ];
