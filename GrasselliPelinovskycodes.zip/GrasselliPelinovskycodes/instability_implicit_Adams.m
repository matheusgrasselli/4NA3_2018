t(1) = 0; y(1) = 1; yM(1) = 1; T = 18; h = 0.1; n = T/h;
t(2) = t(1) + h;        % first step
y(2) = exp(-t(2)^2); yM(2) = y(2);
for k = 2 : n
	t(k+1) = t(k) + h;
	p = y(k) - h*(3*t(k)*y(k)-t(k-1)*y(k-1));
    y(k+1) = y(k) - h*(t(k)*y(k) + t(k+1)*p);
    p = yM(k) - h*t(k)*yM(k);
    yM(k+1) = yM(k) - 2*h*(t(k)+h/2)*p;
end   
yExact = exp(-t.^2); 
plot(t,yExact,':r',t,y,'.b',t,yM,'.g');
axis([0,T,0,1]);


