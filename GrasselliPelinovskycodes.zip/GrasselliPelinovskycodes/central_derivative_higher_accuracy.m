% central_derivative_higher_accuracy
h = logspace(-1,-7,201);
x0 = ones(size(h));                                     % x_0 = 1
xn1 = x0-h;
xn2 = x0-2*h;
xn3 = x0-3*h;
x1 = x0+h;
x2 = x0+2*h;
x3 = x0+3*h;
yDer2Exact = exp(x0);                                   % f(x) = exp(x)
yn1 = exp(xn1);
yn2 = exp(xn2);
yn3 = exp(xn3);
y0 = exp(x0);
y1 = exp(x1);
y2 = exp(x2);
y3 = exp(x3);
yDerCent1 = (y1-yn1)./(2*h);                            % D_1 f(x_0)
eDerCent1 = abs(yDerCent1-yDer2Exact);
yDerCent2 = (-y2+8*y1-8*yn1+yn2)./(12*h);               % D_2 f(x_0)
eDerCent2 = abs(yDerCent2-yDer2Exact);
yDerCent3 = (y3-9*y2+45*y1-45*yn1+9*yn2-yn3)./(60*h);   % D_3 f(x_0)
eDerCent3 = abs(yDerCent3-yDer2Exact);
loglog(h,eDerCent1,'.b',h,eDerCent2,'.r',h,eDerCent3,'.g');