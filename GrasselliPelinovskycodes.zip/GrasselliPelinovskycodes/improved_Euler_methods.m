% improved_Euler_methods
h = 0.05;
y0 = 1;
T = 3;
n = T/h;
t(1) = 0;
yEul(1) = y0;
yHeun(1) = y0;
yMod(1) = y0;
for k = 1 : n
    t(k+1) = t(k)+h;
    yEul(k+1) = yEul(k)+h*(-2*t(k)*yEul(k));
    p = yHeun(k)+h*(-2*t(k)*yHeun(k));
    yHeun(k+1) = yHeun(k)+0.5*h*(-2*t(k)*yHeun(k)-2*t(k+1)*p);
    p = yMod(k)+0.5*h*(-2*t(k)*yMod(k));
    yMod(k+1) = yMod(k)+h*(-2*(t(k)+0.5*h)*p);
end
yExact = exp(-t.^2);
normEul = max(abs(yEul-yExact))
normHeun = max(abs(yHeun-yExact))
normMod = max(abs(yMod-yExact))
plot(t,abs(yHeun-yExact),'.b',t,abs(yMod-yExact),'.g');
 

