h = 0.05; y0 = 1; T = 3; n = T/h; t(1) = 0; 
yEul(1) = y0; yHeun(1) = y0; yMod(1) = y0;  % initial values
for k = 1 : n           
	t(k+1) = t(k) + h;
    yEul(k+1) = yEul(k) + h*(-2*t(k)*yEul(k));  % Euler's method
    p = yHeun(k) + h*(-2*t(k)*yHeun(k));        % Heun's method   
	yHeun(k+1) = yHeun(k) + 0.5*h*(-2*t(k)*yHeun(k)-2*t(k+1)*p);
    p = yMod(k) + 0.5*h*(-2*t(k)*yMod(k));      % modified Euler's method     
	yMod(k+1) = yMod(k) + h*(-2*(t(k)+0.5*h)*p);
end
yExact = exp(-t.^2);    % errors of the three ODE solvers
eEul = abs(yEul-yExact); normEul = max(eEul)
eHeun = abs(yHeun-yExact); normHeun = max(eHeun)
eMod = abs(yMod-yExact); normMod = max(eMod)
plot(t,eHeun,'.b',t,eMod,'.g');
 

