L = 10; xinit = linspace(-L,L,21);
initial_sol = bvpinit(xinit,@myinitial);        % call of "bvpinit"
sol = bvp4c(@myODE,@myboundary,initial_sol);    % call of "bvp4c"
xint = linspace(-L,L,1001);
yint = deval(sol,xint);     % evaluation of the numerical solution
plot(xint,yint(1,:));


