k = 0;
for n = 100 : 10 : 300;
    k = k+1; h(k) = pi/(n-1);
    A = 2*diag(ones(1,n)) - diag(ones(1,n-1),1) - diag(ones(1,n-1),-1);
    [V,D] = eig(A/h(k)^2);
    lambda = diag(D);
    lam1(k) = abs(lambda(1)-1);
    lam2(k) = abs(lambda(2)-4);
    lam3(k) = abs(lambda(3)-9);
end
a1 = polyfit(log(h),log(lam1),1); power1 = a1(1) 
a2 = polyfit(log(h),log(lam2),1); power2 = a2(1) 
a3 = polyfit(log(h),log(lam3),1); power3 = a3(1) 

