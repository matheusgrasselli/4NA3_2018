n = 40; x = linspace(0,2*pi,n+1); 
g = cos(x); r = sin(x);
h = x(2:n+1)-x(1:n);            % linear system for linear finite elements
d1 = (1./h(1:n-1)+1./h(2:n)).*(1-2*g(2:n));
d1 = d1+2*(r(2:n)-r(1:n-1))./(h(1:n-1).^2)-2*(r(2:n)-r(3:n+1))./(h(2:n).^2);
d2 = -(1-g(2:n-1)-g(3:n))./h(2:n-1)-2*(r(3:n)-r(2:n-1))./(h(2:n-1).^2);
d3 = -(1-g(2:n-1)-g(3:n))./h(2:n-1)+2*(r(2:n-1)-r(3:n))./(h(2:n-1).^2);
A = diag(d1) + diag(d2,-1) + diag(d3,+1);
b = (r(1:n-1)-r(2:n))./h(1:n-1)+(r(3:n+1)-r(2:n))./h(2:n); 
y = A\b'; y = [0,y',0];         % plotting finite-element approximation
plot(x,y,'.r',x,y,'b');

 
