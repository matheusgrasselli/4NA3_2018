% error_Romberg_integrations
f = 'cos(x)';
k = 1;
n1 = 4;
n2 = 10;
for n = n1 : n2
hst(k) = pi/(2^n);
  Rnum = Romberg(f,0,pi/2,n);
    R(k,:) = abs(Rnum(1:4)-1);
    k = k+1;
0
end
mSpan = 1:4;
a1 = polyfit(log(hst(mSpan))',log(R(mSpan',1)),1);
power1 = a1(1)
a2 = polyfit(log(hst(mSpan))',log(R(mSpan',2)),1);
power2 = a2(1)
a3 = polyfit(log(hst(mSpan))',log(R(mSpan',3)),1);
power3 = a3(1)
a4 = polyfit(log(hst(mSpan))',log(R(mSpan',4)),1);
power4 = a4(1)
loglog(hst,R,'.');