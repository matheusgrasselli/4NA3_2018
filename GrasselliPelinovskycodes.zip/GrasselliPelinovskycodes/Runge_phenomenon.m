% Runge_phenomenon
for n = 2 : 2 : 40 
    x = linspace(0,pi,n+1); 
    y = sin(x); 
    c = polyfit(x,y,n); 
    xInt = linspace(0,pi,1000); 
    yInt = polyval(c,xInt);
    yExact = sin(xInt); 
    Error(n) = max(abs(yExact-yInt));
end
figure(1); semilogy(Error,'.');

for n = 2 : 2 : 40 
    x = linspace(-1,1,n+1); 
    y = 1./(1+25*x.^2); 
    c = polyfit(x,y,n); 
    xInt = linspace(-1,1,1000); 
    yInt = polyval(c,xInt);
    yExact = 1./(1+25*xInt.^2); 
    Error(n) = max(abs(yExact-yInt));
end 
figure(2); semilogy(Error,'.');

