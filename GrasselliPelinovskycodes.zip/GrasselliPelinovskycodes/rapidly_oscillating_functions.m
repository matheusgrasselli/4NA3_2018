% rapidly_oscillating_functions
x = 0:0.125:1; y = cos(10*pi*x)+2*cos(12*pi*x);
m=-10*pi*sin(10*pi*x)-24*pi*sin(12*pi*x);
xInt = 0 : 0.001 : 1; n = length(x)-1; 
for j = 1 : length(xInt)
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end
xx = xInt-x(iInt);h=diff(x);
            % cubic Hermit polynomials
y0 = y(1:n); m0 = m(1:n);
alpha=(diff(y)./h - m0)./h;
beta=(m(2:n+1)+m(1:n)-2*diff(y)./h)./(h.^2);
yInt=y0(iInt)+m0(iInt).*xx+alpha(iInt).*xx.^2+beta(iInt).*xx.^2.*(xInt-x(iInt+1));
yEx=cos(10*pi*xInt)+2*cos(12*pi*xInt);
plot(x,y,'b.',xInt,yInt,'g',xInt,yEx,'r:');
             % cubic splines
A=2*diag(h(1:n-1))+2*diag(h(2:n))+diag(h(2:n-1),1)+diag(h(2:n-1),-1);
b = 6*((y(3:n+1)-y(2:n))./h(2:n)-(y(2:n)-y(1:n-1))./h(1:n-1));
kappa=A\b'; kappa = [0;kappa;0]';
m=diff(y)./h-h.*(kappa(2:n+1)+2*kappa(1:n))/6;
gamma=diff(kappa)./h(1:n);
yInt=y0(iInt)+m(iInt).*xx+0.5*kappa(iInt).*xx.^2+gamma(iInt).*xx.^3/6;
plot(x,y,'b.',xInt,yInt,'g',xInt,yEx,'r:');
