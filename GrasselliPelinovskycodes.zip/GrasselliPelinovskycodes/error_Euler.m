% error_Euler
t(1) = 0.0001;
y(1) = 1+0.25*t(1)^2;
T = 4+t(1);
nArray = 10:10:10000;
for j = 1 : length(nArray)
    n = nArray(j);
    h(j) = T/n;
    for k = 1 : n
            t(k+1) = t(k)+h(j);
            y(k+1) = y(k)+h(j)*sqrt(y(k)-1);
end
    yExact = 1+0.25*t.^2;
    Eloc(j) = abs(y(2)-yExact(2));
    Eglob(j) = abs(y(n+1)-yExact(n+1));
end
aLoc = polyfit(log(h),log(Eloc),1);
power1 = aLoc(1)
C1 = exp(aLoc(2))
Eapr1 = C1*h.^power1;
aGlob = polyfit(log(h),log(Eglob),1);
power2 = aGlob(1)
C2 = exp(aGlob(2))/T
Eapr2 = T*C2*h.^power2;
loglog(h,Eloc,'.b',h,Eapr1,':r',h,Eglob,'.b',h,Eapr2,':r')

