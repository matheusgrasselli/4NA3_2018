% secant_method
xZeroMATLAB = fzero('x*sin(1/x)-0.5*exp(-x)',0.5); tol = 10^(-14);
total = 100; eps = 1; k = 0; x = 0.5;
% iterations of the Newton method
disp('Iterations of the Newton--Raphson method');

while ((eps > tol) & (k < total))
    f = x*sin(1/x)-0.5*exp(-x);
    f1 = sin(1/x)-cos(1/x)/x+0.5*exp(-x);
    xx = x-f/f1;
    eps = abs(xx-x);
    x = xx;
    k = k+1;
    Error = abs(x - xZeroMATLAB);
    fprintf('x = %12.14f, k = %2.0f, Error = %12.14f\n',x,k,Error);
end
% iterations of the secant method
disp('Iterations of the Secant method'); eps = 1; k = 0; x = 0.5;

f = x*sin(1/x)-0.5*exp(-x); x0 = x; f0 = f; x = x + 0.01;

while ((eps > tol) & (k < total))
    f = x*sin(1/x)-0.5*exp(-x);
    xx = x-f*(x-x0)/(f-f0);
    eps = abs(xx-x);
    x0 = x;
    f0 = f;
    x = xx;
    k = k+1;
    Error = abs(x - xZeroMATLAB);
    fprintf('x = %12.14f, k = %2.0f, Error = %12.14f\n',x,k,Error);
end
