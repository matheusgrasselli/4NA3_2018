x = -3:1:3; y = (cosh(x)).^(-2);
yD = -2*sinh(x).*(cosh(x)).^(-3);
xInt = -3 : 0.001 : 3; yInt = (cosh(xInt)).^(-2);
yInt1 = interp1(x,y,xInt,'spline'); % cubic spline interpolation
yInt2 = interp1(x,y,xInt,'cubic');  % cubic Hermite interpolation
plot(x,y,'r.',xInt,yInt,'r:',xInt,yInt1,'b',xInt,yInt2,'g'); 

[P1,R1] = unmkpp(spline(x,y))       % cubic spline interpolation
SS1 = mkpp(P1,R1);

[P2,R2] = unmkpp(pchip(x,y))        % cubic Hermite interpolation
SS2 = mkpp(P2,R2);

format long;
x0 = 0.5; yExact = (cosh(x0))^(-2)
y1 = ppval(SS1,x0)
y2 = ppval(SS2,x0)
