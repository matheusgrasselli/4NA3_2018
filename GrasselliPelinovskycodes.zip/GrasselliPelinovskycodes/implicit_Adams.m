% implicit_Adams
t(1) = 0;
yAd1(1) = 1;
yAd2(1) = 1;
yAd3(1) = 1;
yAd4(1) = 1;
T = 3;
nArray = 100 : 10 : 2000;
for j = 1 : length(nArray)
    n = nArray(j);
    h(j) = T/n;
    for k = 1 : n
        t(k+1) = t(k)+h(j);
        yAd1(k+1) = yAd1(k)/(1+2*h(j)*t(k+1));
        yAd2(k+1) = (yAd2(k)-h(j)*t(k)*yAd2(k))/(1+h(j)*t(k+1));
end
for k = 1 : 1
        t(k+1) = t(k)+h(j);
        yAd3(k+1) = exp(-t(k+1)^2);
    end
    for k = 2 : n
        t(k+1) = t(k)+h(j);
        yAd3(k+1) = (yAd3(k)-h(j)*(8*t(k)*yAd3(k) ...
                    -t(k-1)*yAd3(k-1))/6)/(1+5*h(j)*t(k+1)/6);
end
for k = 1 : 2
        t(k+1) = t(k)+h(j);
        yAd4(k+1) = exp(-t(k+1)^2);
    end
for k = 3 : n
    
        t(k+1) = t(k)+h(j);
        yAd4(k+1) = (yAd4(k)-h(j)*(19*t(k)*yAd4(k)-5*t(k-1)*yAd4(k-1) ...
                        +t(k-2)*yAd4(k-2))/12)/(1+9*h(j)*t(k+1)/12);
    end
    yExact = exp(-t.^2);
    EAd1(j) = abs(yAd1(n+1)-yExact(n+1));
    EAd2(j) = abs(yAd2(n+1)-yExact(n+1));
    EAd3(j) = abs(yAd3(n+1)-yExact(n+1));
    EAd4(j) = abs(yAd4(n+1)-yExact(n+1));
end
aAd1 = polyfit(log(h),log(EAd1),1);
power1 = aAd1(1)
aAd2 = polyfit(log(h),log(EAd2),1);
power2 = aAd2(1)
aAd3 = polyfit(log(h),log(EAd3),1);
power3 = aAd3(1)
aAd4 = polyfit(log(h),log(EAd4),1);
power3 = aAd4(1)
loglog(h,EAd1,'.b',h,EAd2,'.r',h,EAd3,'.g',h,EAd4,'.c')