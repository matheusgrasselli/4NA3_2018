% shooting_secant_method
h = 0.1; L = input('Enter the half-length of the interval L = ');
x = -L : h : L;
y(1) = 0; u(1) = 0;     % (y,u) - components of u(x)
z(1) = 0; v(1) = 1;     % (z,v) - components of v(x)
for k = 1 : length(x)-1 % iterations of the ODE solver
        yp = y(k) + h*u(k);
        up = u(k) + h*(x(k)^2*y(k)+(3*x(k)^2-1)/((1+x(k)^2)^2));
        y(k+1) = y(k) + 0.5*h*(u(k)+up);
        uu1 = x(k)^2*y(k)+(3*x(k)^2-1)/((1+x(k)^2)^2);
        uu2 = x(k+1)^2*yp+(3*x(k+1)^2-1)/((1+x(k+1)^2)^2);
        u(k+1) = u(k) + 0.5*h*(uu1 + uu2);
        zp = z(k) + h*v(k);
        vp = v(k) + h*x(k)^2*z(k);
        z(k+1) = z(k) + 0.5*h*(v(k)+vp);
        v(k+1) = v(k) + 0.5*h*(x(k)^2*z(k)+x(k+1)^2*zp);
end
s = -y(length(x))/z(length(x)); % linear shooting method
y = y + s*z;                    % resulting solution
if (abs(max(y)) < 1000)
    plot(x,y,'b'); 
else
    disp('ODE solvers fail.');
end

 


