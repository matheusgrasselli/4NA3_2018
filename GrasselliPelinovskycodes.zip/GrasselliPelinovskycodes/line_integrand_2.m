function f=line_integrand_2(t)
% tangential component of the vector field along the path
f=16*cos(t).^3.*sin(t)-4*sin(t).^2; 