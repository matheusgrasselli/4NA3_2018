function Der = CentralDer(n)
% computes coefficients of central differences up to the (2n)-th order

A = diag(ones(2*n,1),1)-diag(ones(2*n,1),-1);
AA = diag(ones(2*n,1),1)+diag(ones(2*n,1),-1)-2*diag(ones(2*n+1,1));
B = A;
C = AA;
for k = 1 : n
    Der(2*k-1,:) = B(n+1,:);
    Der(2*k,:) = C(n+1,:);
    B = B*AA;
    C = C*AA;
end

