t(1) = 0; y(1) = 0.1; z(1) = 0; mu = 10;
T = 50; h = 0.04; n = T/h;
for k = 1 : n       % iterations of the semi-implicit Euler method
    t(k+1) = t(k) + h;
    A = [1, -h ; h*(1+2*mu*y(k)*z(k)), (1-h*mu+h*mu*y(k)^2)];
    b = [y(k); z(k) + 2*h*mu*y(k)^2*z(k)];
    x = A\b; y(k+1) = x(1); z(k+1) = x(2);
end 
figure(1); plot(t,y,'.b'); axis([0,50,-2.5,2.5]);
figure(2); plot(y,z,'.r'); axis([-2.5,2.5,-20,20]);




