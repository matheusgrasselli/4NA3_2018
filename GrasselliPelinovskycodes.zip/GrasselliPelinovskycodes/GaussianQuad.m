function w = GaussianQuad(n)
% computes numerical coefficients of the Gaussian quadrature G_n[-1,1]
x = RootsLegendre(n);
A = fliplr(vander(x))';
b = n./(1:n)';
b(2:2:n) = 0;
w = (A\b)';