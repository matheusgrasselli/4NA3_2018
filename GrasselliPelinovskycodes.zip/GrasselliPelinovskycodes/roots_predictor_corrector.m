% roots_predictor_corrector
hSpan = linspace(0,3,101);
for j = 1 : length(hSpan)
h = hSpan(j);
    q(:,j) = roots([1,-1+h-3*h^2/4,h^2/4])';
end
plot(hSpan,abs(q),'.b');