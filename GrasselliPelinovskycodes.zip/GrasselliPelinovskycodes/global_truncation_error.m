% global_truncation_error
for j = 1 : 2
    if (j == 1)
        a = 0.5;
else
a = 1;
    end
    IntExact = 0.5*(asin(a)+a*sqrt(1-a*a));
    k = 1;
    n1 = 10;
    n2 = 1000;
    for n = n1 : 1 : n2
        h = a/n;
        x = linspace(0,a,n+1);
        y = sqrt(1-x.*x);
        yM = sqrt(1-(x+0.5*h).*(x+0.5*h));
        IntTrap = h*(y(1)+2*sum(y(2:n))+y(n+1))/2;
        IntMid = h*sum(yM(1:n));
        ErrTrap(k) = abs(IntTrap-IntExact);
        ErrMid(k) = abs(IntMid-IntExact);
        hst(k) = h;
        k = k+1;
    end
    aTrap = polyfit(log(hst),log(ErrTrap),1);
    powerTrap = aTrap(1)
    aMid = polyfit(log(hst),log(ErrMid),1);
    powerMid = aMid(1)
end