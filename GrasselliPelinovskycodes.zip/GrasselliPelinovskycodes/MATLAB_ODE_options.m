% MATLAB_ODE_options
y0 = 1;
tspan = [0,0.98];
options = odeset('RelTol',10^(-6),'AbsTol',10^(-6));
p = 1; q = 0;   % options and parameters of the ODE solver
[t,y] = ode45(@ivp2ODE,tspan,y0,options,p,q); 
n = length(t); h = t(2:n)-t(1:n-1); % the dynamical time step
yExact = 1./(1-t); Error = max(abs(y-yExact)) % the global error
figure(1); plot(t,yExact,'r',t,y,'.b'); 
figure(2); semilogy(t(1:n-1),h,'.b');
