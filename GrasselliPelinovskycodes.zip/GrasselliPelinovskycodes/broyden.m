% broyden
tol = 0.0000001; total = 100;  k = 0; epsilon = 1;
xExact = [(-1-5^(1/2))/2;(1-5^(1/2))/2]; x = [-1.5;-0.5]; % third root
D = [1 0;0 1];
while ((epsilon > tol) & (k < total)) % Newton method
    F = [x(1)*x(2)-1;x(2)^2-x(1)-2];
    xnew = x-D\F; epsilon = norm(xnew-x);
    Error = norm(xnew-xExact');
    D = D+[xnew(1)*xnew(2)-1;xnew(2)^2-xnew(1)-2]*(xnew-x)'/((xnew-x)'*(xnew-x));
    x = xnew; k = k+1;
    fprintf('x = %12.10f, y=%12.10f, k= %2.0f, Error= %12.10f \n', ...
        x(1),x(2),k,Error);
end
