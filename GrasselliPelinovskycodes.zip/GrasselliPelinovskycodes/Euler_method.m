% Euler_method
h = 0.1;
y0 = 1;
T = 3;
n = T/h;
t(1) = 0;
y(1) = y0;
% y? = -2 t y
for k = 1 : n
    t(k+1) = t(k)+h;
    y(k+1) = y(k)+h*(-2*t(k)*y(k));
end
yExact = exp(-t.^2);
Error = abs(y-yExact);
plot(t,yExact,'r',t,y,'.b',t,Error,':g');

figure
h = 0.02;
T = 0.94;
n = T/h;
t(1) = 0;
y(1) = y0;
% y'=y^2
for k = 1 : n
    t(k+1) = t(k)+h;
    y(k+1) = y(k)+h*y(k)^2;
end
yExact = 1./(1-t);
Error = abs(y-yExact);
plot(t,yExact,'r',t,y,'.b',t,Error,':g');