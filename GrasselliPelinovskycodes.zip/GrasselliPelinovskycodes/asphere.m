function z=asphere(u,v)
% computes tangent vectors, normal vector and elementary areas
ell = length(u);
tu = [2*cos(u)*cos(v);2*cos(u)*sin(v);-2*sin(u)];
tv = [-2*sin(u)*sin(v);2*sin(u)*cos(v);zeros(1,ell)];
n = cross(tu,tv); % normal vector
for i=1:ell
    z(i)=norm(n(:,i));  % elementary areas
end  