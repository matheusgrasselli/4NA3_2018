function f=line_integrand(t)
% tangential component of the vector field evaluated on the path:
f=(cos(t).^2.*sin(t).^5).*(-sin(t))+(cos(t).^3.*sin(t).^2).*cos(t); 