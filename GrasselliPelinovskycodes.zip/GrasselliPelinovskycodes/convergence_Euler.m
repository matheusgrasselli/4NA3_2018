% convergence_Euler
t(1) = 0;
yEul(1) = 1;
yHeun(1) = 1;
yMod(1) = 1;
T = 3;
nArray = 100 : 10 : 10000;
for j = 1 : length(nArray)
    n = nArray(j);
    h(j) = T/n;
    for k = 1 : n
        t(k+1) = t(k)+h(j);
        yEul(k+1) = yEul(k)+h(j)*(-2*t(k)*yEul(k));
        p = yHeun(k)+h(j)*(-2*t(k)*yHeun(k));
        yHeun(k+1) = yHeun(k)+0.5*h(j)*(-2*t(k)*yHeun(k)-2*t(k+1)*p);
        p = yMod(k)+0.5*h(j)*(-2*t(k)*yMod(k));
        yMod(k+1) = yMod(k)+h(j)*(-2*(t(k)+0.5*h(j))*p);
    end
    yExact = exp(-t.^2);
    EEul(j) = abs(yEul(n+1)-yExact(n+1));
    EHeun(j) = abs(yHeun(n+1)-yExact(n+1));
    EMod(j) = abs(yMod(n+1)-yExact(n+1));
end
aEul = polyfit(log(h),log(EEul),1);
power1 = aEul(1)
aHeun = polyfit(log(h),log(EHeun),1);
power2 = aHeun(1)
aMod = polyfit(log(h),log(EMod),1);
power3 = aMod(1)
loglog(h,EEul,'.b',h,EHeun,'.r',h,EMod,'.c')