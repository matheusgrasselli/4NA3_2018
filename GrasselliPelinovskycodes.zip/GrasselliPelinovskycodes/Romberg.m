function Rnum = Romberg(f,a,b,maxRomb)
% computes recursive Romberg integrations
% f - string for the name of function f(x)
% a,b - lower and upper limits of integration
% maxRomb - the number of recursive Romberg integrations
% Rnum - vector of lowest-error Romberg integrations

R = ones(maxRomb,maxRomb); 
hmin = (b-a)/2^(maxRomb-1); % minimal step size
for k = 1 : maxRomb % trapezoidal rule for the first iteration
    h = 2^(k-1)*hmin;
    x = a : h : b;
    y = eval(f);
    lenY = length(y);
    R(k,1) = 0.5*h*(y(1) + 2*sum(y(2:lenY-1)) + y(lenY));
end
for k = 2 : maxRomb % Romberg integrations
    for kk = 1 : (maxRomb-k+1)
        R(kk,k) = R(kk,k-1)+(R(kk,k-1) - R(kk+1,k-1))/(4^(k-1)-1);
    end
end 
Rnum = R(1,:);