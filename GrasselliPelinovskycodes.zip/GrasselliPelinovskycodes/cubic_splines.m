x = -1 : 0.2 : 3; y = humps(x); n = length(y)-1; 
h = x(2:n+1)-x(1:n);                    % curvatures
A = 2*diag(h(1:n-1)) + 2*diag(h(2:n)) + diag(h(2:n-1),1) + diag(h(2:n-1),-1);
b = 6*((y(3:n+1)-y(2:n))./h(2:n)-(y(2:n)-y(1:n-1))./h(1:n-1)); 
kappa = A\b'; kappa = [0;kappa;0]';     % natural splines
y0 = y(1:n);                            % slopes and third derivatives
m = (y(2:n+1)-y(1:n))./h(1:n)-h(1:n).*(kappa(2:n+1)+2*kappa(1:n))/6;
gamma = (kappa(2:n+1)-kappa(1:n))./h(1:n);  
xInt = -1 : 0.001 : 3; 
for j = 1 : length(xInt)                % intervals between breaking points
    if xInt(j) ~= x(n+1)
        iInt(j) = sum(x <= xInt(j));
    else
        iInt(j) = n;
    end
end 
xx = xInt - x(iInt);
yInt = y0(iInt) + m(iInt).*xx + 0.5*kappa(iInt).*xx.^2 + gamma(iInt).*xx.^3/6; 
yEx = humps(xInt);
plot(x,y,'b.',xInt,yInt,'g',xInt,yEx,'r:'); 
axis([-1,3,-10,100]);
