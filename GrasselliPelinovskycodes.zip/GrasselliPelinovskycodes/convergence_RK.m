% convergence_RK
t(1) = 0;
yEul(1) = 1;
yHeun(1) = 1;
yRK3(1) = 1;
yRK4(1) = 1;
T = 3;
nArray = 100 : 10 : 5000;
for j = 1 : length(nArray)
    n = nArray(j);
    h(j) = T/n;
    for k = 1 : n
        t(k+1) = t(k)+h(j);
        yEul(k+1) = yEul(k)+h(j)*(-2*t(k)*yEul(k));
        p = yHeun(k)+h(j)*(-2*t(k)*yHeun(k));
        yHeun(k+1) = yHeun(k)+0.5*h(j)*(-2*t(k)*yHeun(k)-2*t(k+1)*p);
        fRK3 = -2*t(k)*yRK3(k);
        fRK4 = -2*t(k)*yRK4(k);
        pRK3 = yRK3(k)+h(j)*fRK3/2;
        pRK4 = yRK4(k)+h(j)*fRK4/2;
        gRK3 = -2*(t(k)+h(j)/2)*pRK3;
        gRK4 = -2*(t(k)+h(j)/2)*pRK4;
        qRK3 = yRK3(k)-h(j)*fRK3 + 2*h(j)*gRK3;
        qRK4 = yRK4(k)+h(j)*gRK4/2;
        hRK4 = -2*(t(k)+h(j)/2)*qRK4;
        rRK4 = yRK4(k)+h(j)*hRK4;
        ffRK3 = -2*t(k+1)*qRK3;
        ffRK4 = -2*t(k+1)*rRK4;
        yRK3(k+1) = yRK3(k)+h(j)*(fRK3+4*gRK3+ffRK3)/6;
        yRK4(k+1) = yRK4(k)+h(j)*(fRK4+2*gRK4+2*hRK4+ffRK4)/6;
    end
    yExact = exp(-t.^2);
    EEul(j) = abs(yEul(n+1)-yExact(n+1));
    EHeun(j) = abs(yHeun(n+1)-yExact(n+1));
    ERK3(j) = abs(yRK3(n+1)-yExact(n+1));
    ERK4(j) = abs(yRK4(n+1)-yExact(n+1));
end
aEul = polyfit(log(h),log(EEul),1);
power1 = aEul(1)
aHeun = polyfit(log(h),log(EHeun),1);
power2 = aHeun(1)
aRK3 = polyfit(log(h),log(ERK3),1);
power3 = aRK3(1)
aRK4 = polyfit(log(h),log(ERK4),1);
power4 = aRK4(1)
loglog(h,EEul,'.b',h,EHeun,'.r',h,ERK3,'.c',h,ERK4,'.g')