% comparison_Adams_methods
t(1) = 0;
yAdEx(1) = 1;
yAdIm(1) = 1;
T = 10;
h = 0.2;
n = T/h;
t(2) = t(1)+h;
p = yAdEx(1)+h*(-2*t(1)*yAdEx(1));
yAdEx(2) = yAdEx(1) + 0.5*h*(-2*t(1)*yAdEx(1)-2*t(2)*p);
yAdIm(2) = yAdIm(1)*(1-h*t(1))/(1+h*t(2));
for k = 2 : n
    t(k+1) = t(k)+h;
    yAdEx(k+1) = yAdEx(k)-h*(3*t(k)*yAdEx(k)-t(k-1)*yAdEx(k-1));
    yAdIm(k+1) = yAdIm(k)*(1-h*t(k))/(1+h*t(k+1));
end
yExact = exp(-t.^2);
EAdEx = abs(yAdEx-yExact);
EAdIm = abs(yAdIm-yExact);
semilogy(t,EAdEx,'.b',t,EAdIm,'.r')
T = 20;
h = 0.25;
n = T/h;
for k = 1 : 2
% third-order Adams methods
        t(k+1) = t(k)+h;
        yAdEx(k+1) = exp(-t(k+1)^2);
        yAdIm(k+1) = yAdEx(k+1);
end
for k = 3 : n
    t(k+1) = t(k)+h;
    yAdEx(k+1) = yAdEx(k)-h*(23*t(k)*yAdEx(k) ...
            -16*t(k-1)*yAdEx(k-1)+5*t(k-2)*yAdEx(k-2))/6;
    yAdIm(k+1) = (yAdIm(k)-h*(8*t(k)*yAdIm(k) ...
            -t(k-1)*yAdIm(k-1))/6)/(1+5*h*t(k+1)/6);
end
yExact = exp(-t.^2);
EAdEx = abs(yAdEx-yExact);
EAdIm = abs(yAdIm-yExact);
semilogy(t,EAdEx,'.b',t,EAdIm,'.r')