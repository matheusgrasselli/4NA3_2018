y0 = 1; tspan = 0 : 0.1 : 4; 
[t,y] = ode45(@ivpODE,tspan,y0);
yExact = exp(-t.^2); 
n = length(t)
Error = max(abs(y-yExact))
plot(t,yExact,'r',t,y,'.b');  

