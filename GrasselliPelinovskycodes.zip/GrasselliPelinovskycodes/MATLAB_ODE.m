% MATLAB_ODE
y0 = 1;
tspan = linspace(0,4,41);[t,y] = ode45(@ivpODE,tspan,y0);
yExact = exp(-t.^2); 
n = length(t)
Error = max(abs(y-yExact))
plot(t,yExact,'r',t,y,'.b');  

