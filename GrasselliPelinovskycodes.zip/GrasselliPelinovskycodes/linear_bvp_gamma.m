% linear_bvp_gamma
z = linspace(-1,1,501);
h = z(2)-z(1);
n = length(z)-1;
zz = z(2:n);
gammaSpan = linspace(1,3,201);
for k = 1 : length(gammaSpan)
    gamma = gammaSpan(k);
    A1 = -2*diag(ones(n-1,1))+diag(ones(n-2,1),1)+diag(ones(n-2,1),-1);
    A2 = -h^2*diag((1-gamma*(1-zz.^2))./(1-zz.^2).^2);
    A3 = -h*diag(zz(1:n-2)./(1-zz(1:n-2).^2),1);
    A4 = +h*diag(zz(2:n-1)./(1-zz(2:n-1).^2),-1);
    A = A1+A2+A3+A4;
    b = -h^2*((1-zz.^2).^(3/2))';
    yIn = A\b;
    maxSolution(k) = max(abs(yIn));
end
plot(gammaSpan,maxSolution,'.b');