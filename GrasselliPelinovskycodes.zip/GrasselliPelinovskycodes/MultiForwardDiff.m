function w = MultiForwardDiff(m)
% computes coefficients of the m-point forward difference

x = linspace(1,2,m+1);
h = 1/m;
A = fliplr(vander(x))';
b = (0:m)';
w = h*(A\b)';