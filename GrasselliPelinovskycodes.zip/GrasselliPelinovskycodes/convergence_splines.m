% convergence_splines
n1 = 10;
n2 = 150;
for n = n1 : n2
    x = linspace(0,2*pi,n+1);
    y = sin(x);
    hSpan(n-n1+1) = x(2)-x(1);
    h = x(2)-x(1);
    xInt = linspace(0,2*pi,1001);
    for j = 1 : length(xInt)
        if xInt(j) ~= x(n+1)
            iInt(j) = sum(x <= xInt(j));
        else
            iInt(j) = n;
        end
    end
    xx = xInt-x(iInt);
    yExact = sin(xInt);
    y0 = y(1:n);
    m = diff(y)./diff(x);    % linear splines
    yInt1 = y0(iInt)+m(iInt).*xx;
    Error1(n-n1+1) = max(abs(yExact-yInt1));
    Diff1 = (y(2:n+1)-y(1:n))./(x(2:n+1)-x(1:n));
m(1) = Diff1(1);
m(2) = m(1);        % natural quadratic splines
for k = 1 : n
    m(k+1) = -m(k)+2*Diff1(k);
end

    b = (m(2:n+1)-m(1:n))./(x(2:n+1)-x(1:n));
    m = m(1:n);
    yInt2 = y0(iInt)+m(iInt).*xx+0.5*b(iInt).*xx.^2;
    Error2(n-n1+1) = max(abs(yExact-yInt2));
    h = x(2:n+1)-x(1:n);
    A = 2*diag(h(1:n-1))+2*diag(h(2:n))+diag(h(2:n-1),1)+diag(h(2:n-1),-1);
    Diff2 = (y(3:n+1)-y(2:n))./h(2:n)-(y(2:n)-y(1:n-1))./h(1:n-1);
    b = A\(6*Diff2');
    b = [0;b;0]';                             % natural cubic splines
    m = (y(2:n+1)-y(1:n))./h(1:n)-h(1:n).*(b(2:n+1)+2*b(1:n))/6;
    gamma = (b(2:n+1)-b(1:n))./h(1:n);
    yInt3 = y0(iInt)+m(iInt).*xx+0.5*b(iInt).*xx.^2+gamma(iInt).*xx.^3/6;
    Error3(n-n1+1) = max(abs(yExact-yInt3));
end
a = polyfit(log(hSpan),log(Error1),1);
power1 = a(1)
ErrorApr1 = exp(a(2))*exp(power1*log(hSpan));
b = polyfit(log(hSpan),log(Error2),1);
power2 = b(1)
ErrorApr2 = exp(b(2))*exp(power2*log(hSpan));
c = polyfit(log(hSpan),log(Error3),1);
power3 = c(1)
ErrorApr3 = exp(c(2))*exp(power3*log(hSpan));