% direct_method
clear all
xZeroMATLAB = fzero('2*log(x)+sqrt(x)-2',1.5); epsilon = 1;
tol=0.0000001; total = 100; x(1) = 1; alpha = -1; k = 1;
Error1(1)=abs(x(1)-xZeroMATLAB);
% iterations of the direct method
while ((epsilon > tol) & (k < total))
    x(k+1) = x(k) + alpha*(2*log(x(k))+sqrt(x(k))-2);
    epsilon = abs(x(k+1)-x(k));
    Error1(k+1) = abs(x(k+1) - xZeroMATLAB);
    k=k+1;
end
fprintf('Root x = %12.10f is found after %2.0f iterations\n',x(k),k-1);
% improved value for alpha
fDer = 2/xZeroMATLAB + 1/(2*sqrt(xZeroMATLAB)); alpha = -1/fDer;
clear x
x(1)=1; j =1; epsilon = 1;
Error2(1)=abs(x(1)-xZeroMATLAB);
% iterations of the direct method
while ((epsilon > tol) & (j < total))
    x(j+1) = x(j) + alpha*(2*log(x(j))+sqrt(x(j))-2);
    epsilon = abs(x(j+1)-x(j));
    Error2(j+1) = abs(x(j+1) - xZeroMATLAB);
    j = j+1;
end
fprintf('Root x = %12.10f is found after %2.0f iterations\n',x(j),j-1);
