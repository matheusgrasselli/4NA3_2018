% relaxation_method
n = 50; h = 1/n; x = 0 : h : 1; y = 0 : h : 1;
for j = 1 : 3  % three explicit iterations
    if (j == 1)
        omega = 0.5;
    elseif (j == 2)
        omega = 1;
    else
        omega = 2/(1+sin(pi/n));
    end
    u = zeros(n+1,n+1);  % boundary values
    u(1,:) = sin(pi*x); u(:,1) = sin(2*pi*y');
    l = 0; nor = 1;
    while( (nor > 10^(-6)) & (l < 10000))
        l = l + 1; uu = u;
        for k = 2 : n-1
            for m = 2 : n-1
                ut = u(k-1,m) + u(k+1,m) + u(k,m-1) + u(k,m+1);
                ut = ut + h^2*sin(pi*x(k))*sin(pi*y(k));
                u(k,m) = (1-omega)*u(k,m)+0.25*omega*ut;
            end
        end
        nor = max(max(abs(u-uu)));
    end
    fprintf('Number of iterations for omega = %f is %d\n',omega,l);
end
[X,Y] = meshgrid(x,y); mesh(X,Y,u);
