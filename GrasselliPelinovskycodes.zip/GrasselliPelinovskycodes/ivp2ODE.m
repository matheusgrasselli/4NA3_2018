function [y1] = ivp2ODE(t,y,p,q)
    y1 = p*y.^2+q*t.^2;  

