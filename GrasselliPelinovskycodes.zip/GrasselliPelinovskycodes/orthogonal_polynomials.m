% orthogonal_polynomials
x = 0 : 0.1 : 5; 
n = length(x)-1; 
y = exp(-x).*cos(x); 
p(1,:) = ones(size(x)); % discrete orthogonal polynomials
for k = 1 : n
    alpha = (p(k,:)*(x.*p(k,:))')/(p(k,:)*p(k,:)');    
    if k == 1
        p(k+1,:) = (x-alpha).*p(k,:);
    else
        beta = (p(k,:)*p(k,:)')/(p(k-1,:)*p(k-1,:)');
        p(k+1,:) = (x-alpha).*p(k,:)- beta*p(k-1,:);
        % three-term recurrence relation
    end
end
for k = 1 : n+1
    p(k,:) = p(k,:)/sqrt(p(k,:)*p(k,:)'); % normalization
end
for m = 1 : 41  % computations of approximations p_m(x)
    yy = zeros(size(x));
    for k = 1 : m+1
        c(k) = y*p(k,:)';
        yy = yy + c(k)*p(k,:);
    end
    E(m) = sum((y-yy).^2);  % approximation error
end
semilogy(E,'.');
