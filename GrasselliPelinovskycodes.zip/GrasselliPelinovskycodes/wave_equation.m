h = 0.01; x = 0 : h : 1;                    % grid in space
nX = length(x)-2; x1 = x(2:nX+1);
tau = 0.0125; r = tau/h; t = 0 : tau : 1;   % grid in time
nT = length(t); U1 = zeros(nX,nT); 
U1(:,1) = sin(pi*x1'); U2 = U1;             % initial conditions
d1 = diag(ones(1,nX)); d2 = diag(ones(1,nX-1),1)+diag(ones(1,nX-1),-1);
A1 = 2*(1-r^2)*d1+r^2*d2; A2 = 2*(1+r^2)*d1-r^2*d2; 
U1(:,2) = 0.5*A1*U1(:,1)+tau*sin(2*pi*x1'); % first steps
U2(:,2) = 2*inv(A2)*U2(:,1)+tau*sin(2*pi*x1');
for k = 3 : nT                              % further steps
        U1(:,k) = A1*U1(:,k-1)-U1(:,k-2); 
        U2(:,k) = 4*inv(A2)*U2(:,k-1)-U2(:,k-2);
end
U1 = [ zeros(1,length(t)); U1; zeros(1,length(t)) ];
U2 = [ zeros(1,length(t)); U2; zeros(1,length(t)) ];
[X,T1] = meshgrid(x,t(1:(nT-1-12*2)/2));
figure(1); surf(X,T1,U1(:,1:(nT-1-12*2)/2)');
xlabel('x'); ylabel('t'); zlabel('u');
[X,T] = meshgrid(x,t);
figure(2); surf(X,T,U2');
xlabel('x'); ylabel('t'); zlabel('u'); 




