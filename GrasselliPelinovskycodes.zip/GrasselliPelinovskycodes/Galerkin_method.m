m = 5; j = 1 : m;
b = 40*(1 - (-1).^j)./(pi^3*j.^3);              % inhomogeneous term
u = zeros(1,m); u(3) = 0.2;                     % initial condition
T = 0.5; t = linspace(0,T,101); dt = t(2)-t(1); % time grid
uSpectrum(1,:) = u;
for k = 1 : length(t)-1                         % fourth-order Runge-Kutta method
     k1 = -pi^2*j.^2.*u+b; u1 = u + 0.5*dt*k1;
     k2 = -pi^2*j.^2.*u1+b; u2 = u + 0.5*dt*k2;
     k3 = -pi^2*j.^2.*u2+b; u3 = u + dt*k3;
     k4 = -pi^2*j.^2.*u3+b;
     u = u + dt*(k1+2*k2+2*k3+k4)/6; 
     uSpectrum(k+1,:) = u;
end 
x = linspace(0,1,101);
U = zeros(length(t),length(x));
for k = 1 : length(t)                           % solution surface
    for jj = 1 : m
        U(k,:) = U(k,:) + uSpectrum(k,jj)*sin(pi*jj*x);
    end
end
kx = length(x); kt = length(t);
x = x(1:2:kx); t = t(1:2:kt);
U = U(:,1:2:kx); U = U(1:2:kt,:);
[X,T] = meshgrid(x,t); mesh(X,T,U); 
xlabel('x'); ylabel('t'); zlabel('u'); 
