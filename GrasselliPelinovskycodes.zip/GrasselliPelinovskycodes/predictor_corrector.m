t(1) = 0; y(1) = 1; f(1) = 0; T = 4; 
nArray = 100 : 5 : 2000;
for j = 1 : length(nArray)  % approximations for different time steps
    n = nArray(j); h(j) = T/n; 
    t(2) = t(1) + h(j); y(2) = exp(-t(2)^2); f(2) = -2*t(2)*y(2);
    t(3) = t(2) + h(j); y(3) = exp(-t(3)^2); f(3) = -2*t(3)*y(3);
    t(4) = t(3) + h(j); y(4) = exp(-t(4)^2); f(4) = -2*t(4)*y(4);
    for k = 4 : n           % iterations of the predictor-corrector pair
			t(k+1) = t(k) + h(j);
			p = y(k) + h(j)*(55*f(k)-59*f(k-1)+37*f(k-2)-9*f(k-3))/24;
            ff = -2*t(k+1)*p;
            y(k+1) = y(k) + h(j)*(9*ff+19*f(k)-5*f(k-1)+f(k-2))/24;
            f(k+1) = -2*t(k+1)*y(k+1);
    end   
    yExact = exp(-t.^2); 
    Eloc(j) = abs(y(5)-yExact(5));
    Eglob(j) = abs(y(n+1)-yExact(n+1));
end
aLoc = polyfit(log(h),log(Eloc),1);     % power fit of local error
power1 = aLoc(1), Eapr1 = exp(aLoc(2))*h.^power1;
aGlob = polyfit(log(h),log(Eglob),1);   % power fit of global error
power2 = aGlob(1), Eapr2 = exp(aGlob(2))*h.^power2;
loglog(h,Eloc,'.b',h,Eapr1,':r',h,Eglob,'.g',h,Eapr2,':r')


