h = 0.01; x = 0 : h : 1; m = 0; aa = 0;
a = input('Enter an initial approximation for eigenvalue = ');
while (abs(a-aa) > 10^(-10)) & (m < 1000)
    aa = a;
    y(1) = 1; u(1) = 0;                      % (y,u) - components of u(x)
    y(2) = 1 - a*x(2)^2/4; u(2) = -a*x(2)/2; % power series approximation
    z(1) = 0; v(1) = 0;                      % (z,v) - components of v(x)   
    z(2) = -x(2)^2/4; v(2) = -x(2)/2;
    for k = 2 : length(x)-1                  % Heun's method
        yp = y(k) + h*u(k); up = u(k) - h*(u(k)/x(k)+a*y(k));
        y(k+1) = y(k) + 0.5*h*(u(k)+up);
        u(k+1) = u(k) - 0.5*h*(u(k)/x(k)+a*y(k)+up/x(k+1)+a*yp);
        zp = z(k) + h*v(k); vp = v(k) - h*(v(k)/x(k)+a*z(k)+y(k));
        z(k+1) = z(k) + 0.5*h*(v(k)+vp);
        v(k+1) = v(k) - 0.5*h*(v(k)/x(k)+a*z(k)+vp/x(k+1)+a*zp+y(k)+yp);
    end
    a = aa - y(length(x))/z(length(x));      % shooting method
    m = m+1;
end
fprintf('Final approximation of eigenvalue = %f\n',a)
fprintf('The shooting method converges in %d iterations\n',m);
plot(x,y);                                    % plotting eigenfunction

