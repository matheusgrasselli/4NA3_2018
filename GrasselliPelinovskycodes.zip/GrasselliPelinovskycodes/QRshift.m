function [B,V,iterations] = QRshift(A,tol)
% QR algorithm with shifts
% V eigenvector matrix
% B vector of eigenvalues

[n,m] = size(A); V = eye(n); iterations = zeros(1,n);
for i=n:-1:2
    while norm(A(i,1:i-1)) > tol
        shift = A(i,i);
        [Q,R] = householderQR(A-shift*eye(i));
        A = R*Q+shift*eye(i);
        V(1:n,1:i) = V(1:n,1:i)*Q;
        iterations(i) = iterations(i)+1;
    end
    B(i) = A(i,i);
    A = A(1:i-1,1:i-1);
end
B(1) = A(1,1);
