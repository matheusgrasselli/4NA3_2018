a = 1; IntExact = tanh(a);  
k = 1; n1 = 10; n2 = 1000;
for n = n1 : 2 : n2
    h = a/n; x = linspace(0,a,n+1); y = 1./(cosh(x).^2);
    IntTrap = h*(y(1)+2*sum(y(2:n))+y(n+1))/2; 
    ErrTrap(k) = abs(IntTrap-IntExact); % composite trapezoidal rule
    IntSimp = h*(y(1)+4*sum(y(2:2:n))+2*sum(y(3:2:n-1))+y(n+1))/3; 
    ErrSimp(k) = abs(IntSimp-IntExact); % composite Simpson's rule
    hst(k) = h;  k = k+1;
end
aTrap = polyfit(log(hst),log(ErrTrap),1); powerTrap = aTrap(1)
aSimp = polyfit(log(hst),log(ErrSimp),1); powerSimp = aSimp(1)
loglog(hst,ErrTrap,'g',hst,ErrSimp,'r'); 
