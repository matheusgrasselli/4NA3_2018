% nonlinear_bvp
L = input('Enter the length of the interval, L = ');
x = linspace(-L,L,201);
h = x(2)-x(1);
n = length(x)-1;
y = tanh(x)';
y(1) = -1;
y(n+1) = 1;
tolerance = 10^(-10);
solutionNorm = 1;
k = 0;
maxNumber = 100;
while ((solutionNorm > tolerance) & (k < maxNumber))
    J1 = -2*diag(ones(n-1,1))+diag(ones(n-2,1),1)+diag(ones(n-2,1),-1);
    J2 = 2*h^2*diag(1-3*y(2:n).^2);
    J = J1+J2;
    F = y(3:n+1)-2*y(2:n)+y(1:n-1)+2*h^2*y(2:n).*(1-y(2:n).^2);
    yy = y(2:n)-inv(J)*F;
    yy = [-1;yy;1];
    solutionNorm = max(abs(y-yy));
    y = yy;
    k = k+1;
    distance(k) = solutionNorm;
end
if (k < maxNumber)
    fprintf('The iterative algorithm converges in %d iterations\n',k);
    figure(1); plot(x,y','.b',x,tanh(x),':r');
else
    fprintf('The iterative algorithm does not converge.\n')
    figure(2); plot(distance);
end