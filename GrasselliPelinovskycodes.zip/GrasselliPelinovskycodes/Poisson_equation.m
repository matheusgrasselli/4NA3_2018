% Poisson_equation
% u = [u11,u21,u31,u12,u22,u32,u13,u23,u33]
n = 3;
n2 = n^2;
A = -4*diag(ones(n2,1))+diag(ones(n2-1,1),1)+diag(ones(n2-1,1),-1)...
    +diag(ones(n2-n,1),n)+diag(ones(n2-n,1),-n);
h = 0.25;
x = [0.25, 0.5,0.75];
b1 = sin(pi*x);
b2 = sin(2*pi*x);
b= -[b1(1)+b2(1);b1(2);b1(3);b2(2);0;0;b2(3);0;0];
c1 = -h^2*sin(pi*x')*sin(pi*x(1));
c2 = -h^2*sin(pi*x')*sin(pi*x(2));
c3 = -h^2*sin(pi*x')*sin(pi*x(3));
c = [c1;c2;c3];
r = b+c;
u = A\r;
u1 = u(1:3)';
u2 = u(4:6)';
u3 = u(7:9)';
x = 0:0.25:1;
y = 0:0.25:1;
[X,Y] = meshgrid(x,y);
u0 = sin(pi*x);
u1 = [b2(1),u1,0];
u2 = [b2(2),u2,0];
u3 = [b2(3),u3,0];
u4 = zeros(1,5);
Z = [u0;u1;u2;u3;u4];
mesh(X,Y,Z);