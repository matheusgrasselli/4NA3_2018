function [V,D] = QRit(A,maxit)
% pure QR algorithm for eigenpairs
% V eigenvector matrix
% B eigenvalue matrix

[n,m] = size(A); V = eye(n);
for i = 1 : maxit
    [Q,R] = householderQR(A);
    A = R*Q;
    V = V*Q;
end
D = A;
