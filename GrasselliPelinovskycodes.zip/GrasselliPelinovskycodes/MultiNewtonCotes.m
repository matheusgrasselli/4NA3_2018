function w = MultiNewtonCotes(n)
% computes coefficients of the Newton--Cotes integration rules
x = linspace(0,1,n+1);
h = 1/n;
A = fliplr(vander(x))';
b = 1./(1:n+1)';
w = (A\b)'/h;
