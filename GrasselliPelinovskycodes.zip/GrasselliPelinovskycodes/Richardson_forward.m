% Richardson_forward
h = logspace(-1,-10,101);
for k = 1 : length(h)
    yDerExact = exp(1);
    Dnum = ForwRichExtrap('exp(x)',1,h(k),4);
    eDerForw(k,:) = abs(Dnum-yDerExact);
end
loglog(h',eDerForw,'.');
