
% polynomial_approximation
x = linspace(-0.5,4.5,201);
y = x.^3-6*x.^2+8*x-10+2*(0.5-rand(size(x)));
n = length(x)-1;
m = 3;
V = vander(x);
V = V(:,n-m+1:n+1);
A = V'*V;
b = V'*y';
c = (A\b)'
xApr = linspace(-0.5,4.5,201);
yApr = polyval(c,xApr);
yEx = xApr.^3-6*xApr.^2+8*xApr-10;
plot(x,y,'.g',xApr,yApr,'b',xApr,yEx,':m');