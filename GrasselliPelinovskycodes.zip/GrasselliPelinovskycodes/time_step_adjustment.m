h = 0.001; H(1) = h; k = 1; t(1) = 0; y(1) = 1;
E(1) = 0; Etol = 10^(-10);  % initial error and tolerance
while (t(length(t)) < 0.99)
    k1 = y(k)^2;            % Runge-Kutta solver with h
    k2 = (y(k) + 0.5*h*k1)^2;
    k3 = (y(k) + 0.5*h*k2)^2;
    k4 = (y(k) + h*k3)^2;
    y(k+1) = y(k) + h*(k1+2*k2+2*k3+k4)/6;
    k1 = y(k)^2;            % Runge-Kutta solver with h/2
    k2 = (y(k) + 0.25*h*k1)^2;
    k3 = (y(k) + 0.25*h*k2)^2;
    k4 = (y(k) + 0.5*h*k3)^2;
    yH = y(k) + h*(k1+2*k2+2*k3+k4)/12;
    k1 = yH^2;
    k2 = (yH + 0.25*h*k1)^2;
    k3 = (yH + 0.25*h*k2)^2;
    k4 = (yH + 0.5*h*k3)^2;
    yy = yH + h*(k1+2*k2+2*k3+k4)/12;
    E(k+1) = abs(16*(yy-y(k+1))/15);    % error formula
    h = h*(Etol/E(k+1))^(1/5);          % time step adjustment
    t(k+1) = t(k) + h;
    k1 = y(k)^2;            % new Runge-Kutta solver with h_opt
    k2 = (y(k) + 0.5*h*k1)^2;
    k3 = (y(k) + 0.5*h*k2)^2;
    k4 = (y(k) + h*k3)^2;
    y(k+1) = y(k) + h*(k1+2*k2+2*k3+k4)/6;
    H(k+1) = h;
    k = k+1;
end
yExact = 1./(1-t); Eexact = abs(yExact-y);
figure(1); semilogy(t,E,'.b',t,Eexact,':r'); 
figure(2); semilogy(t,H,'.b');