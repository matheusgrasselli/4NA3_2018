function Der = ForwardDer(n)
% computes coefficients of forward differences up to the n-th order

A = diag(ones(n,1),1)-diag(ones(n+1,1));
B = A;
for k = 1 : n
    Der(k,:) = B(1,:);
B = A*B; end