n = 10:10:400;
for k = 1 : length(n)
    nn = n(k); hh = 1/nn; h(k) = hh;
    x = linspace(0,1,nn+1); xx = x(2:nn);
    A1 = -2*diag(ones(nn-1,1))+diag(ones(nn-2,1),1)+diag(ones(nn-2,1),-1);
    A2 = 2*hh^2*diag(1./(1+xx.^2))-hh*diag(xx(1:nn-2)./(1+xx(1:nn-2).^2),1);
    A3 = hh*diag(xx(2:nn-1)./(1+xx(2:nn-1).^2),-1);
    A = A1 + A2 + A3; 
    b = hh^2*(1+xx.^2)';
    b(1) = b(1)-(1 + hh*xx(1)/(1+xx(1)^2))*2;
    b(nn-1) = b(nn-1)-(1 - hh*xx(nn-1)/(1+xx(nn-1)^2))*5/3;
    u = A\b; y = [ 2; u; 5/3]';
    yExact = x.^4/6-3*x.^2/2+x+2;
    Error(k) = max(abs(y - yExact));
end
a = polyfit(log(h),log(Error),1); power = a(1)   % best power fit
hInt = linspace(h(1),h(length(h)),101);
ErrorInt = exp(a(2)+a(1)*log(hInt));
plot(h,Error,'.b',hInt,ErrorInt,':r');