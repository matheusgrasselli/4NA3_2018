function Y = rayleigh(A,x0,maxit,tol)
% Rayleigh quotient iteration

[m,n] = size(A); x = x0; i = 1; 
lambda = x'*A*x;
error=norm(A*x-lambda*x);
while (i < maxit) & (error > tol)
    w = (A-lambda*eye(m))\x;
    x = w/norm(w);
    lambda = x'*A*x;
    error = norm(A*x-lambda*x);
   Y(i,:) = [x;lambda;error].';
    i=i+1;
end
