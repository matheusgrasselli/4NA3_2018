n = 50; m = n/2; x = linspace(0,2*pi,n+1);
f = cos(x(1:n)); g = sin(x(1:n));       % inhomogeneous terms
j = -m : m;                             % discrete Fourier transform for g(x)
for jj = 1 : length(j)
    a(jj) = g*exp(-i*j(jj)*x(1:n)');
end
c = zeros(size(a));                     % initial approximation
for k = 1 : n
    u(k) = real(c(2:n)*exp(i*(-m+1:m-1)'*x(k)));
    u(k) = (u(k)+(c(1)*exp(-i*m*x(k))+c(n+1)*exp(i*m*x(k)))/2)/n;
end
tau = 0.001; du = 1; toler = 10^(-9); 
count = 0; term = 100000;               % pseudospectral method
while ((du > toler) & (count < term))
      ff = f.*u;                        % discrete transform for f(x) u_k(x)
      for jj = 1 : length(j)
           b(jj) = ff*exp(-i*j(jj)*x(1:n)');
      end
      cc = c + tau*(-j.^2.*c-b+a);
      for k = 1 : n                     % inverse transform for u_{k+1}(x)
            uu(k) = real(cc(2:n)*exp(i*(-m+1:m-1)'*x(k)));
            uu(k) = (uu(k)+(cc(1)*exp(-i*m*x(k))+cc(n+1)*exp(i*m*x(k)))/2)/n;
      end
      du = max(abs(uu-u)); c = cc;
      u = uu; count = count + 1;
end
fprintf('The algorithm converges after %d iterations\n',count);
u(n+1) = u(1); plot(x,u,'.'); xlabel('x'); ylabel('u'); 

