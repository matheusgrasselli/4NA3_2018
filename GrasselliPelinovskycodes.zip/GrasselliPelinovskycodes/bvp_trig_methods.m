n = 100; x = linspace(0,2*pi,n+1);
f = diag(cos(x(1:n)));              % collocation method
g = sin(x(1:n))';
D = -diag(ones(1,n))*(n^2/12+1/6);  % matrix for second derivatives
for j = 1 : n-1
    for k = j+1 : n
        D(j,k) = 0.5*(-1)^(j-k-1)/(sin(pi*(j-k)/n))^2;
        D(k,j) = D(j,k);
    end
end
A = -D + f; u = A\g; u(n+1) = u(1);
m = n/2; j = -m : m;                % Galerkin method
A = diag(j.^2) + 0.5*(diag(ones(n,1),1) + diag(ones(n,1),-1));
gg = zeros(n+1,1);                  % inhomogeneous term
gg(m) = -1/(2*i); gg(m+2) = 1/(2*i);
c = A\gg;                           % solution in Fourier space
xx = linspace(0,2*pi,1001); uu = zeros(1,1001);
for k = 1 : n+1                     % solution in physical space
    uu = uu + c(k)*exp(i*j(k)*xx);
end
plot(x,u,'.b',xx,real(uu),'r'); 
xlabel('x'); ylabel('u'); 


