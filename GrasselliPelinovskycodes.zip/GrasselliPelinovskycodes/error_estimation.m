h = 0.01; k = 1; t(1) = 0; y(1) = 1; yy = 1; E(1) = 0;
while (t(length(t)) < 0.9)
    t(k+1) = t(k) + h;
    k1 = y(k)^2;                % Runge-Kutta solver with h
    k2 = (y(k) + 0.5*h*k1)^2;
    k3 = (y(k) + 0.5*h*k2)^2;
    k4 = (y(k) + h*k3)^2;
    y(k+1) = y(k) + h*(k1+2*k2+2*k3+k4)/6;
    k1 = yy^2;                  % Runge-Kutta solver with h/2
    k2 = (yy + 0.25*h*k1)^2;
    k3 = (yy + 0.25*h*k2)^2;
    k4 = (yy + 0.5*h*k3)^2;
    yH = yy + h*(k1+2*k2+2*k3+k4)/12;
    k1 = yH^2;
    k2 = (yH + 0.25*h*k1)^2;
    k3 = (yH + 0.25*h*k2)^2;
    k4 = (yH + 0.5*h*k3)^2;
    yy = yH + h*(k1+2*k2+2*k3+k4)/12;
    E(k+1) = 16*abs(yy-y(k+1))/15;
    k = k+1;
end
yExact = 1./(1-t); Eexact = abs(yExact-y);
semilogy(t,E,'.b',t,Eexact,':r'); 
MaxError = max(abs(E-Eexact))

