function [Q,R]=modifiedQR(A)
% modified QR factorization for n x k matrix A
% Q is n x k left-orthogonal matrix
% R is k x k upper triangular matrix with positive diagonal entries
% A = Q*R

[n,k] = size(A);
for i = 1:k
    R(i,i) = norm(A(:,i));
    if  R(i,i) == 0
        error('matrix is not of full rank')
    end
    Q(:,i) = A(:,i)/R(i,i);
    for j = i+1:k
        R(i,j) = Q(:,i)'*A(:,j);
        A(:,j) = A(:,j)-R(i,j)*Q(:,i);
    end
end
