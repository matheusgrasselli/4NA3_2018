% improper_integration
IntExact = pi/2;
nn = 10 : 10 : 40000;
for k = 1:length(nn)
    n = nn(k);
    hh = 1./n;
    x = linspace(0,1,n+1);
    y1 = 1./sqrt(1-x(1:n).^2);
    y1M = 1/sqrt(1-(1-0.5*hh).^2);
    h(k) = hh;
    IntTrap1(k) = hh*(y1(1)+2*sum(y1(2:n-1))+y1(n))/2 + hh*y1M;
end
semilogx(h,IntTrap1,'g',h,IntExact*ones(size(h)),':g')
 for k = 1:length(nn)
    n = nn(k);
    hh = pi./(2*n);
    x = linspace(0,pi/2,n+1);
    y2 = cos(x(2:n+1))./sin(x(2:n+1));
    y2M = cos(0.5*hh)/sin(0.5*hh);
    h(k) = hh;
    IntTrap2(k) = hh*y2M + hh*(y2(1)+2*sum(y2(2:n-1))+y2(n))/2;
 end
figure
semilogx(h,IntTrap2,'b')