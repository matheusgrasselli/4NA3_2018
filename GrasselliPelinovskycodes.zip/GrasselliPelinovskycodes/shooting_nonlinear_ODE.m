h = 0.01; x = 0 : h : 10; m = 0; ss = 0;
s = input('Enter starting value for s = ');     % user input
while (abs(s-ss) > 10^(-10)) & (abs(s-ss) < 100) & (m < 1000)
    ss = s; y(1) = s; u(1) = 0;         % (y,u) - components of u(x)
    y(2) = s + s*(1-s^2)*x(2)^2/4;      % Taylor series approximation
    u(2) = s*(1-s^2)*x(2)/2;            % for the first step
    z(1) = 1; v(1) = 0;                 % (z,v) - components of v(x)
    z(2) = 1 + (1-3*s^2)*x(2)^2/4;
    v(2) = (1-3*s^2)*x(2)/2;
    for k = 2 : length(x)-1             % iterations of the ODE solver
        yp = y(k) + h*u(k);
        up = u(k) - h*(u(k)/x(k)-y(k)+y(k)^3);
        y(k+1) = y(k) + 0.5*h*(u(k)+up);
        u(k+1) = u(k) - 0.5*h*(u(k)/x(k)-y(k)+y(k)^3+up/x(k+1)-yp+yp^3);
        zp = z(k) + h*v(k);
        vp = v(k) - h*(v(k)/x(k)-z(k)+3*y(k)^2*z(k));
        z(k+1) = z(k) + 0.5*h*(v(k)+vp);
        v(k+1) = v(k) - 0.5*h*(v(k)/x(k)-z(k)+3*y(k)^2*z(k)+vp/x(k+1)-vp+3*yp^2*zp);
    end
    s = ss - y(length(x))/z(length(x)); m = m+1;
    if (m == 1)
        plot(x,y,':r'); hold on;
    end
end
if (abs(s-ss) < 100) & (m < 1000)
    fprintf('The shooting method converges in %d iterations\n',m);
    plot(x,y,'b');
else
    disp('The shooting method fails.');
end  


