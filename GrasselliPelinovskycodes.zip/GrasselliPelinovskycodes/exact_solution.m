T = 1; h = 0.1; x = 0 : h : 1; 
nX = length(x)-2; x1 = x(2:nX+1);
tau = h; t = 0 : tau : T; nT = length(t); 
U1 = zeros(nX,nT); U1(:,1) = sin(pi*x1'); 
A1 = diag(ones(1,nX-1),1)+diag(ones(1,nX-1),-1);  
U1(:,2) = 0.5*A1*U1(:,1)+tau*sin(2*pi*x1'); 
for k = 3 : nT
        U1(:,k) = A1*U1(:,k-1)-U1(:,k-2); 
end
Uexact = cos(pi*T)*sin(pi*x1')+sin(2*pi*T)*sin(2*pi*x1')/(2*pi);
Error = max(abs(Uexact-U1(:,nT)))
