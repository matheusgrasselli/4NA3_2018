T = 1; r = 0.5; 
for h = 0.01 : 0.01 : 0.02
    x = 0 : h : 1; nX = length(x)-2; 
    x1 = x(2:nX+1); tau = r*h; 
    t = 0 : tau : T; nT = length(t); 
    U1 = zeros(nX,nT); U1(:,1) = sin(pi*x1'); 
    U2 = U1; d1 = diag(ones(1,nX));
    d2 = diag(ones(1,nX-1),1)+diag(ones(1,nX-1),-1);
    A1 = 2*(1-r^2)*d1+r^2*d2; A2 = 2*(1+r^2)*d1-r^2*d2; 
    U1(:,2) = 0.5*A1*U1(:,1)+tau*sin(2*pi*x1'); 
    U2(:,2) = 2*inv(A2)*U2(:,1)+tau*sin(2*pi*x1');
    for k = 3 : nT
        U1(:,k) = A1*U1(:,k-1)-U1(:,k-2); 
        U2(:,k) = 4*inv(A2)*U2(:,k-1)-U2(:,k-2);
    end
    Uexact = cos(pi*T)*sin(pi*x1')+sin(2*pi*T)*sin(2*pi*x1')/(2*pi);
    if (h == 0.01)
        E1a = max(abs(Uexact-U1(:,nT)));
        E2a = max(abs(Uexact-U2(:,nT)));
        fprintf('E1a = %f, E2a = %f\n',E1a,E2a);
    elseif (h == 0.02)
        E1b = max(abs(Uexact-U1(:,nT)));
        E2b = max(abs(Uexact-U2(:,nT)));
        fprintf('E1b = %f, E2b = %f\n',E1b,E2b);
        R1 = E1b/E1a; R2 = E2b/E2a;
        fprintf('R1 = %f, R2 = %f\n',R1,R2);
    end
end

