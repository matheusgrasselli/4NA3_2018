% roots_explicit_Adams_continued
for j = 1 : length(hSpan)
    h = hSpan(j);
    q3(:,j) = roots([1,-1+23*h/12,-4*h/3,5*h/12])';
    q4(:,j) = roots([1,-1+55*h/24,-59*h/24,37*h/24,-9*h/24])';
end
figure(2); plot(hSpan,abs(q3),'.b');
figure(3); plot(hSpan,abs(q4),'.b');